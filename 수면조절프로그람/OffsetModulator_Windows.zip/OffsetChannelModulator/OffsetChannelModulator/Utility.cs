﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace OffsetChannelModulator
{
    public static class Utility
    {
        public static Font GlobalFont;
        public static bool CheckMono(string filename)
        {
            AudioFileReader af = new AudioFileReader(filename);
            if (af.WaveFormat.Channels < 2)
                return true;
            else
                return false;
        }

        public static int GenerateOffset(string filename, bool isCircadian, int wakeupTime = 6)
        {
            //Applying random jitters
            Random random = new Random((int)DateTime.Now.TimeOfDay.TotalMilliseconds);
            int randDev = 0;
            bool hq = false;
            if (!filename.ToLower().EndsWith(".flac"))
            {
                hq = false;
                randDev = isCircadian ? random.Next(1, 4) : random.Next(1, 61);
            }
            else
            {
                hq = true;
                randDev = isCircadian ? random.Next(1, 6) : random.Next(1, 121);
            }
            if (isCircadian)
            {
                randDev += GetDeviation(wakeupTime, hq);
            }


            return randDev;
        }

        public static bool CheckCustomRange(string filename, int max)
        {
            if (!filename.ToLower().EndsWith(".flac"))
            {
                if (max > 60)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (max > 120)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static int GenerateOffset(int min, int max)
        {
            Random random = new Random((int)DateTime.Now.TimeOfDay.TotalMilliseconds);
            return random.Next(min, max + 1);
        }

        public static bool Save(object obj, string filename)
        {///Save object into filename
            if (obj == null) return false;
            try
            {
                using (Stream stream = File.Open(filename, FileMode.Create))
                {
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, obj);
                }
                return true;
            }
            catch (IOException ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public static object Load(string filename)
        {///Load object from filename
            try
            {
                using (Stream stream = File.Open(filename, FileMode.Open))
                {
                    BinaryFormatter bin = new BinaryFormatter();

                    var obj = bin.Deserialize(stream);
                    return obj;
                }
            }
            catch (IOException ex)
            {
                Debug.WriteLine(ex.Message);
                return null;
            }
        }

        public static List<double> SinConsts = new List<double>
        {
            0.196393398,
            0.383910728,
            0.556674583,
            0.708045747,
            0.832207109,
            0.924387219,
            0.609815084,
            0.761268268,
            0.894328342,
            0.971464030,
            0.907777744,
            0.810252844,
            0.682524699,
            0.529354545,
            0.356452000,
            0.170262237,
            0.001000000,
            0.001000000,
            0.001000000,
            0.001000000,
            0.001000000,
            0.001000000,
            0.001000000,
            0.001000000
        };

        public static int GetDeviation(int wakeupTime, bool hq)
        {
            DateTime now = DateTime.Now;
            //Shifting SinConsts so that  the first real element will be for the wakeupTime
            var refValues = GetShiftedSinConsts(wakeupTime);

            double deviation = GetSinValue(refValues, now);

            if (hq)
            {
                deviation = Math.Floor(deviation * 120 + 1);
            }
            else
            {
                deviation = Math.Floor(deviation * 60 + 1);
            }
            return (int)deviation;
        }

        public static double GetSinValue(List<double> refValue, DateTime dateTime)
        {
            int hour = dateTime.Hour;
            double fraction = dateTime.Minute / 60.0;
            double lowerbound = refValue[hour];
            double upperbound = 0;
            if (hour == 23)
            {
                upperbound = refValue[0];
            }
            else
            {
                upperbound = refValue[hour + 1];
            }
            return lowerbound + (upperbound - lowerbound) * fraction;
        }

        public static List<double> GetShiftedSinConsts(int wakeupTime)
        {
            List<double> refValues = new List<double>();
            foreach (var c in SinConsts)
            {
                refValues.Add(c);
            }
            for (int i = 0; i < wakeupTime; i++)
            {
                refValues.Insert(0, refValues.Last());
                refValues.RemoveAt(refValues.Count - 1);
            }
            refValues.Add(refValues[0]);
            return refValues;
        }

        public static List<Profile> ProfileList = new List<Profile>();
    }
}
