﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OffsetChannelModulator
{
    [Serializable()]
    public class Profile
    {
        public string Name;
        public bool IsLeft;
        public int Offset;
        public bool RandStart;
        public int OffsetMin;
        public int OffsetMax;
        public string OutputFolder;
    }
}
