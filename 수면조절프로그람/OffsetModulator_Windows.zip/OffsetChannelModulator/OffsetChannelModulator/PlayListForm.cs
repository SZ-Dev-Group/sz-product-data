﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OffsetChannelModulator
{
    public partial class PlayListForm : Form
    {
        public PlayListForm(List<string> filelist)
        {
            InitializeComponent();
            listBox.Items.Clear();
            foreach (var f in filelist)
            {
                listBox.Items.Add(Path.GetFileName(f));
            }
        }
    }
}
