﻿using NAudio.MediaFoundation;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OffsetChannelModulator
{
    public partial class ConvertForm : Form
    {
        StreamingForm Parent;
        List<string> FileList = new List<string>();
        private MyAudioFileReader audioFile;
        int Offset = 0;
        bool IsLeft = true;
        int OffsetMin = 0;
        int OffsetMax = 60;
        bool RandStart = false;
        string OutputFolder = "";
        string ProfileName = "";

        public ConvertForm(StreamingForm parent)
        {
            Parent = parent;
            InitializeComponent();
            LoadProfile();
        }

        private void ConvertForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Save profile list
            SaveProfile();
            Application.Exit();
        }

        private void SaveProfile()
        {
            //Create app dir
            string appDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "offset");
            if (!Directory.Exists(appDir))
            {
                Directory.CreateDirectory(appDir);
            }
            Utility.Save(Utility.ProfileList, Path.Combine(appDir, "profiles"));
        }

        private void LoadProfile()
        {
            string appDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "offset");
            Utility.ProfileList = Utility.Load(Path.Combine(appDir, "profiles")) as List<Profile>;
            if (Utility.ProfileList == null) Utility.ProfileList = new List<Profile>();
            //Updating GUI
            comboBoxProfile.Items.Clear();
            foreach (var p in Utility.ProfileList)
            {
                comboBoxProfile.Items.Add(p.Name);
            }
            if (Utility.ProfileList.Count == 0) return;
            Profile profile = Utility.ProfileList[0];
            UpdateGUIFromProfile(profile);
            comboBoxProfile.SelectedIndex = 0;
        }

        private void UpdateGUIFromProfile(Profile profile)
        {
            if (profile.IsLeft)
            {
                radioButtonLeft.Checked = true;
                radioButtonRight.Checked = false;
                LeftChannelControlPanel.Enabled = true;
                RightChannelControlPanel.Enabled = false;

                leftChannelOffset.Value = profile.Offset;
                checkBoxRandomLeft.Checked = profile.RandStart;
                leftCustomMin.Value = profile.OffsetMin;
                leftCustomMax.Value = profile.OffsetMax;

                rightChannelOffset.Value = 1;
                checkBoxRandomRight.Checked = false;
                rightCustomMin.Value = 1;
                rightCustomMax.Value = 1;
            }
            else
            {
                radioButtonLeft.Checked = false;
                radioButtonRight.Checked = true;
                LeftChannelControlPanel.Enabled = false;
                RightChannelControlPanel.Enabled = true;

                rightChannelOffset.Value = profile.Offset;
                checkBoxRandomRight.Checked = profile.RandStart;
                rightCustomMin.Value = profile.OffsetMin;
                rightCustomMax.Value = profile.OffsetMax;

                leftChannelOffset.Value = 1;
                checkBoxRandomLeft.Checked = false;
                leftCustomMin.Value = 1;
                leftCustomMax.Value = 1;
            }
            if (profile.OutputFolder != "")
                labelExportFolder.Text = profile.OutputFolder;
        }

        private void buttonOpenStreaming_Click(object sender, EventArgs e)
        {
            Hide();
            Parent.Show();
        }

        private void buttonOpenFiles_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "mp3, wav files (*.mp3, *.wav)|*.mp3;*.wav|flac files (*.flac)|*.flac";
            openFileDialog.Title = "Select music files";
            openFileDialog.Multiselect = true;
            DialogResult result = openFileDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                FileList = new List<string>();
                foreach (var s in openFileDialog.FileNames)
                {
                    FileList.Add(s);
                }
                //Update fileload status
                if (openFileDialog.FilterIndex == 1)
                {
                    labelFileLoadStatus.Text = string.Format("{0} mp3 and wav files loaded.", FileList.Count);
                }
                else
                {
                    labelFileLoadStatus.Text = string.Format("{0} flac files loaded.", FileList.Count);
                }
            }
        }

        private void radioButtonLeft_CheckedChanged(object sender, EventArgs e)
        {
            LeftChannelControlPanel.Enabled = radioButtonLeft.Checked;
            RightChannelControlPanel.Enabled = radioButtonRight.Checked;
        }

        private void radioButtonRight_CheckedChanged(object sender, EventArgs e)
        {
            LeftChannelControlPanel.Enabled = radioButtonLeft.Checked;
            RightChannelControlPanel.Enabled = radioButtonRight.Checked;
        }

        private bool UpdateParameters()
        {
            IsLeft = radioButtonLeft.Checked;
            if (IsLeft)
            {
                Offset = (int)leftChannelOffset.Value;
                OffsetMin = (int)leftCustomMin.Value;
                OffsetMax = (int)leftCustomMax.Value;
                RandStart = checkBoxRandomLeft.Checked;
            }
            else
            {
                Offset = (int)rightChannelOffset.Value;
                OffsetMin = (int)rightCustomMin.Value;
                OffsetMax = (int)rightCustomMax.Value;
                RandStart = checkBoxRandomRight.Checked;
            }
            if (labelExportFolder.Text == "No folder selected")
            {
                OutputFolder = "";
            }
            else
            {
                OutputFolder = labelExportFolder.Text;
            }
            //Check inputs
            if (RandStart && (OffsetMin > OffsetMax))
            {
                MessageBox.Show("Please set the custom range correctly. If you do not use custom range, set both to be zero.",
                    "Custom Offset Range", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (OutputFolder == "")
            {
                MessageBox.Show("Output folder is not selected.", "Outfolder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;
        }

        private void buttonExportFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.SelectedPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            folderBrowserDialog.Description = "Select the output folder.";
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                labelExportFolder.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private async void buttonExport_Click(object sender, EventArgs e)
        {
            if (comboBoxProfile.SelectedIndex < 0)
            {
                MessageBox.Show("Please choose an profile name or create one.", "Profile selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!UpdateParameters())
            {
                return;
            }
            if (FileList.Count == 0)
            {
                MessageBox.Show("No files are loaded to convert.", "File not loaded",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //Updating current profile with current GUI parameters
            Profile profile = Utility.ProfileList[comboBoxProfile.SelectedIndex];
            profile.Name = comboBoxProfile.SelectedItem as string;
            profile.IsLeft = IsLeft;
            profile.Offset = Offset;
            profile.RandStart = RandStart;
            profile.OffsetMax = OffsetMax;
            profile.OffsetMin = OffsetMin;
            profile.OutputFolder = OutputFolder;
            //Use this profile to convert files
            //Before that, check Custom Range of the current profile
            if (profile.RandStart)
            {
                if (OffsetMin > 0)
                {
                    if (!Utility.CheckCustomRange(FileList[0], OffsetMax))
                    {
                        MessageBox.Show("Custom Range is not suitable for these files. For mp3 and wav, 1~60, for flac, 1~120.",
                            "Custom Range", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
            //Now proceed with conversion
            buttonExport.Text = "Converting...";
            buttonExport.Enabled = false;
            comboBoxProfile.Enabled = false;
            buttonCreateProfile.Enabled = false;
            buttonOpenFiles.Enabled = false;
            buttonExportFolder.Enabled = false;
            await Task.Run(() =>
            {
                int count = 0;
                string logfile = Path.Combine(OutputFolder,
                    profile.Name + "_" + DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss") + ".csv");
                using (StreamWriter writer = new StreamWriter(logfile, true))
                {
                    //Writing header
                    //file#, filetype, filename, offset start timecode for left and right, offset end timecode for left and right, offset for left and right, export file name
                    writer.WriteLine("File #,FileType,Filename,Left Offset,Right Offset,Offset_start_timecode_left,Offset_end_timecode_left," +
                        "Offset_start_timecode_right,Offset_end_timecode_right,Offset_Applied_Export_Filename");
                }
                foreach (var filename in FileList)
                {
                    count++;
                    string rs = Convert(filename, profile, logfile);
                    using (StreamWriter writer = new StreamWriter(logfile, true))
                    {
                        writer.WriteLine(count.ToString() + "," + rs);
                    }
                    buttonExport.Invoke((MethodInvoker)delegate
                    {
                        buttonExport.Text = string.Format("{0:0.0}% complete", (double)count / FileList.Count * 100);
                    });
                }
            });
            buttonExport.Text = "Export";
            buttonExport.Enabled = true;
            comboBoxProfile.Enabled = true;
            buttonCreateProfile.Enabled = true;
            buttonOpenFiles.Enabled = true;
            buttonExportFolder.Enabled = true;
            MessageBox.Show("Conversion complete. Log is created in the output folder.", "Convert", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonCreateProfile_Click(object sender, EventArgs e)
        {
            if (!UpdateParameters())
            {
                return;
            }
            InputForm inputForm = new InputForm();
            DialogResult result = inputForm.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                ProfileName = inputForm.ProfileName;
                foreach (var p in Utility.ProfileList)
                {
                    if (p.Name == ProfileName)
                    {
                        MessageBox.Show("This profile name is already here. Please choose a new one.",
                            "Profile Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ProfileName = "";
                        return;
                    }
                }
                Profile profile = new Profile
                {
                    Name = ProfileName,
                    IsLeft = IsLeft,
                    Offset = Offset,
                    RandStart = RandStart,
                    OffsetMin = OffsetMin,
                    OffsetMax = OffsetMax,
                    OutputFolder = OutputFolder
                };
                Utility.ProfileList.Add(profile);
                comboBoxProfile.Items.Add(ProfileName);
                comboBoxProfile.SelectedIndex = Utility.ProfileList.Count - 1;
            }
        }

        private string Convert(string filename, Profile profile, string logfile)
        {
            //check mono
            if (Utility.CheckMono(filename))
            {
                ConvertMonoToStereo(filename);
            }
            //setting offset value based on the profile
            int offset = profile.Offset;
            if (profile.RandStart)
            {
                if (OffsetMin < OffsetMax)
                {
                    offset = Utility.GenerateOffset(OffsetMin, OffsetMax);
                }
                else
                {
                    offset = Utility.GenerateOffset(filename,false);
                }
            }
            //Converting file
            audioFile = new MyAudioFileReader(filename, offset, profile.IsLeft);
            //Output file name
            string outputFile = Path.GetFileNameWithoutExtension(filename) + "_" + (profile.IsLeft ? "L" : "R") +
                offset.ToString();
            outputFile = Path.Combine(OutputFolder, outputFile);
            string wavOutputFile = outputFile + ".wav";
            string mp3OutputFile = outputFile + ".mp3";

            string outputFileName = "";

            WaveFileWriter.CreateWaveFile(wavOutputFile, audioFile);
            MediaFoundationApi.Startup();
            bool deleteWav = true;
            using (var reader = new WaveFileReader(wavOutputFile))
            {
                try
                {
                    MediaFoundationEncoder.EncodeToMp3(reader, mp3OutputFile);
                    //on successful conversion, remove wav file
                    deleteWav = true;
                    outputFileName = mp3OutputFile;
                }
                catch (InvalidOperationException ex)
                {
                    //In case we fail, try to delete the mp3 file
                    if (File.Exists(mp3OutputFile))
                    {
                        File.Delete(mp3OutputFile);
                    }
                    deleteWav = false;
                    outputFileName = wavOutputFile;
                }
            }

            if (deleteWav)
            {
                File.Delete(wavOutputFile);
            }

            //file#, filetype, filename, offset start timecode for left and right, offset end timecode for left and right, offset for left and right, export file name
            //offset start and end timecode for left, offset start and end timecode for right, export file name

            //Creating log
            //2. filetype
            string filetype = "";
            if (filename.ToLower().EndsWith("mp3")) filetype = "mp3";
            else if (filename.ToLower().EndsWith("wav")) filetype = "wav";
            else filetype = "flac";
            //3. file_name
            string file_name = Path.GetFileNameWithoutExtension(filename);
            //4,5. offset for left
            string offset_for_left = "";
            string offset_for_right = "";
            if (profile.IsLeft)
            {
                offset_for_left = offset.ToString();
                offset_for_right = "0";
            }
            else
            {
                offset_for_right = offset.ToString();
                offset_for_left = "0";
            }
            //6,7,8,9. offset_start_timecode_left, offset_end_timecode_left
            string offset_start_timecode_left = "";
            string offset_end_timecode_left = "";
            string offset_start_timecode_right = "";
            string offset_end_timecode_right = "";
            if (profile.IsLeft)
            {
                offset_start_timecode_left = GetStartTimecode(offset, audioFile);
                offset_end_timecode_left = GetEndTimecode(offset, audioFile);
                offset_start_timecode_right = GetStartTimecode(0, audioFile);
                offset_end_timecode_right = GetEndTimecode(0, audioFile);
            }
            else
            {
                offset_start_timecode_left = GetStartTimecode(0, audioFile);
                offset_end_timecode_left = GetEndTimecode(0, audioFile);
                offset_start_timecode_right = GetStartTimecode(offset, audioFile);
                offset_end_timecode_right = GetEndTimecode(offset, audioFile);
            }
            //10. export filename
            string offset_applied_export_filename = Path.GetFileNameWithoutExtension(outputFileName);
            //assemblying output string
            string result = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8}",
                filetype, file_name,
                offset_for_left, offset_for_right,
                offset_start_timecode_left, offset_end_timecode_left,
                offset_start_timecode_right, offset_end_timecode_right,
                offset_applied_export_filename);

            //after conversion, dispose audiofilereader
            audioFile.Dispose();
            audioFile = null;

            return result;
        }

        private void ConvertMonoToStereo(string monoFilePath)
        {
            string outputFilePath = Path.Combine(Path.GetDirectoryName(monoFilePath), "temp.wav");
            using (var inputReader = new AudioFileReader(monoFilePath))
            {
                // convert our mono ISampleProvider to stereo
                var stereo = new MonoToStereoSampleProvider(inputReader);
                stereo.LeftVolume = 1.0f; // silence in left channel
                stereo.RightVolume = 1.0f; // full volume in right channel

                WaveFileWriter.CreateWaveFile16(outputFilePath, stereo);
                File.Delete(monoFilePath);
                File.Copy(outputFilePath, monoFilePath);
            }
        }

        private string GetStartTimecode(int offset, MyAudioFileReader audioFile)
        {
            if (audioFile == null)
            {
                return "00:00:00.00000";
            }
            return AssembleTimecode(TimeSpan.FromTicks(offset * 100));
        }

        private string GetEndTimecode(int offset, MyAudioFileReader audioFile)
        {
            if (audioFile == null)
            {
                return "00:00:00.00000";
            }
            TimeSpan duration = audioFile.GetDuration();
            return AssembleTimecode(duration.Add(TimeSpan.FromTicks(offset * 100)));
        }

        private string AssembleTimecode(TimeSpan timeSpan)
        {
            if (timeSpan == null)
            {
                return "00:00:00.00000";
            }
            else
            {
                string timecode = timeSpan.ToString("G");
                return timecode.Substring(2, timecode.Length - 4);
            }
        }

        private void comboBoxProfile_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxProfile.SelectedIndex < 0) return;
            UpdateGUIFromProfile(Utility.ProfileList[comboBoxProfile.SelectedIndex]);
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            Hide();
            Parent.Show();
            //Save profile list
            SaveProfile();
        }

        private void buttonRemoveProfile_Click(object sender, EventArgs e)
        {
            int index = comboBoxProfile.SelectedIndex;
            if (index < 0) return;
            Utility.ProfileList.RemoveAt(index);
            comboBoxProfile.Items.RemoveAt(index);
        }
    }
}
