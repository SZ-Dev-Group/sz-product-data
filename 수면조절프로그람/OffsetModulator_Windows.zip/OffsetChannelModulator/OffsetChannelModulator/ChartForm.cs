﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace OffsetChannelModulator
{
    public partial class ChartForm : Form
    {
        private int WakeupTime;
        private string filename;
        public ChartForm(int wakeupTime, string filename)
        {
            InitializeComponent();
            WakeupTime = wakeupTime;
            this.filename = filename;
        }

        private void ChartForm_Load(object sender, EventArgs e)
        {
            var refPoints = Utility.GetShiftedSinConsts(WakeupTime);
            var deviationData = chart.Series[0].Points;
            deviationData.Clear();
            for (int i = 0; i < 25; i++)
            {
                DataPoint point = new DataPoint();
                point.XValue = i;
                point.YValues = new double[] { refPoints[i] };
                point.MarkerStyle = MarkerStyle.Circle;
                deviationData.Add(point);
            }

            DateTime now = DateTime.Now;
            labelSystemTime.Text = now.ToString("HH:mm:ss");

            labelDeviation.Text = Utility.GetSinValue(Utility.GetShiftedSinConsts(WakeupTime), now).ToString("F6");

            if (string.IsNullOrEmpty(filename))
            {
                labelOffset.Text = "N/A";
            }
            else
            {
                bool hq = false;
                if (filename.ToLower().EndsWith("mp3"))
                {
                    hq = false;
                }
                else
                {
                    hq = true;
                }
                //Showing only the offset calculated from the formular, excluding the random jitter.
                labelOffset.Text = Utility.GetDeviation(WakeupTime, hq).ToString();
            }
        }
    }
}
