﻿using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OffsetChannelModulator
{
    public class MyAudioFileReader : AudioFileReader
    {

        private int BytePerSampleChannel;
        private int BytePerSample;
        private int ChannelNo = 0;
        private Queue<byte> OffsetBuffer;
        private int Offset;
        private int BufferCount;
        private int RealPosition;
        public bool IsLeft;
        public int OffsetTime;

        /// <summary>
        /// Initializes a new instance of AudioFileReader
        /// </summary>
        /// <param name="fileName">The file to open</param>
        public MyAudioFileReader(string fileName, int offset, bool isleft) : base(fileName)
        {
            //adding some blank data to the end of the file by offset
            BytePerSampleChannel = WaveFormat.BitsPerSample / 8;
            BytePerSample = BytePerSampleChannel * WaveFormat.Channels;
            OffsetBuffer = new Queue<byte>();
            OffsetTime = offset;
            Offset = TimeToByte(offset);
            if (isleft) ChannelNo = 0;
            else ChannelNo = 1;
            BufferCount = 0;
            RealPosition = 0;
            IsLeft = isleft;
        }

        /// <summary>
        /// Reads from this wave stream
        /// </summary>
        /// <param name="buffer">Audio buffer</param>
        /// <param name="offset">Offset into buffer</param>
        /// <param name="count">Number of bytes required</param>
        /// <returns>Number of bytes read</returns>

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (BufferCount == 0) BufferCount = count;

            var waveBuffer = new WaveBuffer(buffer);
            int samplesRequired = count / 4;
            int samplesRead = Read(waveBuffer.FloatBuffer, offset / 4, samplesRequired);
            if (RealPosition < Length)
            {
                for (int i = 0; i < samplesRead * 4 / BytePerSample; i++)
                {
                    for (int c = 0; c < WaveFormat.Channels; c++)
                    {
                        for (int p = 0; p < BytePerSampleChannel; p++)
                        {
                            if (c == ChannelNo)
                            {
                                OffsetBuffer.Enqueue(buffer[i * BytePerSample + c * BytePerSampleChannel + p]);
                                if (RealPosition < Offset)
                                {
                                    buffer[i * BytePerSample + c * BytePerSampleChannel + p] = 0;
                                }
                                else if (RealPosition < Length)
                                {
                                    buffer[i * BytePerSample + c * BytePerSampleChannel + p] = OffsetBuffer.Dequeue();
                                }
                            }
                            RealPosition++;
                        }
                    }
                }
                if (samplesRead == 0)
                { }
                return samplesRead * 4;
            }
            else
            {
                if (OffsetBuffer.Count <= BufferCount * BytePerSampleChannel / BytePerSample)
                {
                    BufferCount = OffsetBuffer.Count / BytePerSampleChannel * BytePerSample;
                }

                for (int i = 0; i < BufferCount / BytePerSample; i++)
                {
                    for (int c = 0; c < WaveFormat.Channels; c++)
                    {
                        for (int j = 0; j < BytePerSampleChannel; j++)
                        {
                            if (c == ChannelNo)
                            {
                                buffer[i * BytePerSample + c * BytePerSampleChannel + j] = OffsetBuffer.Dequeue();
                            }
                            else
                            {
                                buffer[i * BytePerSample + c * BytePerSampleChannel + j] = 0;
                            }
                        }
                    }
                }
                return BufferCount;
            }
        }

        private int TimeToByte(int offsetTime) // offsetTime in 1/100000 seconds
        {
            double seconds = offsetTime / 100000.0;
            int numOfSamples = (int)(seconds * WaveFormat.SampleRate);
            return numOfSamples * BytePerSample;
        }

        public TimeSpan GetDuration()
        {//before modification
            return TimeSpan.FromSeconds(Length / BytePerSample / WaveFormat.SampleRate);
        }
    }
}
