﻿namespace OffsetChannelModulator
{
    partial class StreamingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOpenFiles = new System.Windows.Forms.Button();
            this.buttonOpenConverter = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonLeftEar = new System.Windows.Forms.RadioButton();
            this.radioButtonRightEar = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonPlayRandom = new System.Windows.Forms.Button();
            this.buttonPlayPrev = new System.Windows.Forms.Button();
            this.buttonPlayPause = new System.Windows.Forms.Button();
            this.buttonPlayNext = new System.Windows.Forms.Button();
            this.buttonPlayRepeat = new System.Windows.Forms.Button();
            this.labelAlbum = new System.Windows.Forms.Label();
            this.labelSong = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonPlaylist = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelLeftStart = new System.Windows.Forms.Label();
            this.labelLeftEnd = new System.Windows.Forms.Label();
            this.labelRightStart = new System.Windows.Forms.Label();
            this.labelRightEnd = new System.Windows.Forms.Label();
            this.WakeTimeBar = new System.Windows.Forms.TrackBar();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonGraph = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CircadianSyncCheck = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WakeTimeBar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonOpenFiles
            // 
            this.buttonOpenFiles.BackColor = System.Drawing.Color.White;
            this.buttonOpenFiles.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonOpenFiles.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonOpenFiles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenFiles.Location = new System.Drawing.Point(13, 11);
            this.buttonOpenFiles.Name = "buttonOpenFiles";
            this.buttonOpenFiles.Size = new System.Drawing.Size(100, 57);
            this.buttonOpenFiles.TabIndex = 0;
            this.buttonOpenFiles.Text = "Open Files";
            this.buttonOpenFiles.UseVisualStyleBackColor = false;
            this.buttonOpenFiles.Click += new System.EventHandler(this.buttonOpenFiles_Click);
            // 
            // buttonOpenConverter
            // 
            this.buttonOpenConverter.BackColor = System.Drawing.Color.White;
            this.buttonOpenConverter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonOpenConverter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonOpenConverter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenConverter.Location = new System.Drawing.Point(313, 11);
            this.buttonOpenConverter.Name = "buttonOpenConverter";
            this.buttonOpenConverter.Size = new System.Drawing.Size(100, 57);
            this.buttonOpenConverter.TabIndex = 1;
            this.buttonOpenConverter.Text = "Offset Converter";
            this.buttonOpenConverter.UseVisualStyleBackColor = false;
            this.buttonOpenConverter.Click += new System.EventHandler(this.buttonOpenConverter_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(14, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.groupBox1.Size = new System.Drawing.Size(399, 75);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Offset Affinity";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.radioButtonLeftEar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.radioButtonRightEar, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(11, 28);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(377, 38);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // radioButtonLeftEar
            // 
            this.radioButtonLeftEar.AutoSize = true;
            this.radioButtonLeftEar.Checked = true;
            this.radioButtonLeftEar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLeftEar.Location = new System.Drawing.Point(3, 3);
            this.radioButtonLeftEar.Name = "radioButtonLeftEar";
            this.radioButtonLeftEar.Size = new System.Drawing.Size(182, 32);
            this.radioButtonLeftEar.TabIndex = 0;
            this.radioButtonLeftEar.TabStop = true;
            this.radioButtonLeftEar.Text = "Left Ear";
            this.radioButtonLeftEar.UseVisualStyleBackColor = true;
            this.radioButtonLeftEar.CheckedChanged += new System.EventHandler(this.radioButtonLeftEar_CheckedChanged);
            // 
            // radioButtonRightEar
            // 
            this.radioButtonRightEar.AutoSize = true;
            this.radioButtonRightEar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRightEar.Location = new System.Drawing.Point(191, 3);
            this.radioButtonRightEar.Name = "radioButtonRightEar";
            this.radioButtonRightEar.Size = new System.Drawing.Size(183, 32);
            this.radioButtonRightEar.TabIndex = 1;
            this.radioButtonRightEar.Text = "Right Ear";
            this.radioButtonRightEar.UseVisualStyleBackColor = true;
            this.radioButtonRightEar.CheckedChanged += new System.EventHandler(this.radioButtonRightEar_CheckedChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Controls.Add(this.buttonPlayRandom, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonPlayPrev, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonPlayPause, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonPlayNext, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonPlayRepeat, 4, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(28, 422);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(371, 64);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // buttonPlayRandom
            // 
            this.buttonPlayRandom.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.suffle_off;
            this.buttonPlayRandom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayRandom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlayRandom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayRandom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlayRandom.Location = new System.Drawing.Point(11, 9);
            this.buttonPlayRandom.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.buttonPlayRandom.Name = "buttonPlayRandom";
            this.buttonPlayRandom.Size = new System.Drawing.Size(52, 46);
            this.buttonPlayRandom.TabIndex = 0;
            this.buttonPlayRandom.UseVisualStyleBackColor = true;
            this.buttonPlayRandom.Click += new System.EventHandler(this.buttonPlayRandom_Click);
            // 
            // buttonPlayPrev
            // 
            this.buttonPlayPrev.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.prev;
            this.buttonPlayPrev.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayPrev.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlayPrev.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayPrev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlayPrev.Location = new System.Drawing.Point(85, 9);
            this.buttonPlayPrev.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.buttonPlayPrev.Name = "buttonPlayPrev";
            this.buttonPlayPrev.Size = new System.Drawing.Size(52, 46);
            this.buttonPlayPrev.TabIndex = 1;
            this.buttonPlayPrev.UseVisualStyleBackColor = true;
            this.buttonPlayPrev.Click += new System.EventHandler(this.buttonPlayPrev_Click);
            // 
            // buttonPlayPause
            // 
            this.buttonPlayPause.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.play;
            this.buttonPlayPause.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayPause.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlayPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayPause.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlayPause.Location = new System.Drawing.Point(159, 9);
            this.buttonPlayPause.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.buttonPlayPause.Name = "buttonPlayPause";
            this.buttonPlayPause.Size = new System.Drawing.Size(52, 46);
            this.buttonPlayPause.TabIndex = 2;
            this.buttonPlayPause.UseVisualStyleBackColor = true;
            this.buttonPlayPause.Click += new System.EventHandler(this.buttonPlayPause_Click);
            // 
            // buttonPlayNext
            // 
            this.buttonPlayNext.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.next;
            this.buttonPlayNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayNext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlayNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlayNext.Location = new System.Drawing.Point(233, 9);
            this.buttonPlayNext.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.buttonPlayNext.Name = "buttonPlayNext";
            this.buttonPlayNext.Size = new System.Drawing.Size(52, 46);
            this.buttonPlayNext.TabIndex = 3;
            this.buttonPlayNext.UseVisualStyleBackColor = true;
            this.buttonPlayNext.Click += new System.EventHandler(this.buttonPlayNext_Click);
            // 
            // buttonPlayRepeat
            // 
            this.buttonPlayRepeat.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.repeat_off;
            this.buttonPlayRepeat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayRepeat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlayRepeat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayRepeat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlayRepeat.Location = new System.Drawing.Point(307, 9);
            this.buttonPlayRepeat.Margin = new System.Windows.Forms.Padding(11, 9, 11, 9);
            this.buttonPlayRepeat.Name = "buttonPlayRepeat";
            this.buttonPlayRepeat.Size = new System.Drawing.Size(53, 46);
            this.buttonPlayRepeat.TabIndex = 4;
            this.buttonPlayRepeat.UseVisualStyleBackColor = true;
            this.buttonPlayRepeat.Click += new System.EventHandler(this.buttonPlayRepeat_Click);
            // 
            // labelAlbum
            // 
            this.labelAlbum.Location = new System.Drawing.Point(0, 0);
            this.labelAlbum.Name = "labelAlbum";
            this.labelAlbum.Size = new System.Drawing.Size(399, 27);
            this.labelAlbum.TabIndex = 0;
            this.labelAlbum.Text = "Album Title";
            this.labelAlbum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSong
            // 
            this.labelSong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSong.Location = new System.Drawing.Point(0, 27);
            this.labelSong.Name = "labelSong";
            this.labelSong.Size = new System.Drawing.Size(399, 27);
            this.labelSong.TabIndex = 1;
            this.labelSong.Text = "Song Name";
            this.labelSong.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Currently Streaming";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.buttonPlaylist);
            this.panel1.Controls.Add(this.tableLayoutPanel3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.labelSong);
            this.panel1.Controls.Add(this.labelAlbum);
            this.panel1.Location = new System.Drawing.Point(14, 366);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(399, 337);
            this.panel1.TabIndex = 3;
            // 
            // buttonPlaylist
            // 
            this.buttonPlaylist.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.list;
            this.buttonPlaylist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlaylist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlaylist.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(158)))), ((int)(((byte)(71)))));
            this.buttonPlaylist.Location = new System.Drawing.Point(3, 3);
            this.buttonPlaylist.Name = "buttonPlaylist";
            this.buttonPlaylist.Size = new System.Drawing.Size(30, 30);
            this.buttonPlaylist.TabIndex = 4;
            this.buttonPlaylist.UseVisualStyleBackColor = true;
            this.buttonPlaylist.Click += new System.EventHandler(this.buttonPlaylist_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label5, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label7, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.labelLeftStart, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.labelLeftEnd, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.labelRightStart, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.labelRightEnd, 1, 5);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(4, 146);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(391, 185);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.tableLayoutPanel3.SetColumnSpan(this.label2, 2);
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(385, 33);
            this.label2.TabIndex = 0;
            this.label2.Text = "Left Channel";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.tableLayoutPanel3.SetColumnSpan(this.label3, 2);
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(385, 33);
            this.label3.TabIndex = 1;
            this.label3.Text = "Right Channel";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "Start Timecode";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(198, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 29);
            this.label5.TabIndex = 3;
            this.label5.Text = "End Timecode";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(189, 29);
            this.label6.TabIndex = 4;
            this.label6.Text = "Start Timecode";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(198, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(190, 29);
            this.label7.TabIndex = 5;
            this.label7.Text = "End Timecode";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelLeftStart
            // 
            this.labelLeftStart.AutoSize = true;
            this.labelLeftStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelLeftStart.ForeColor = System.Drawing.Color.Black;
            this.labelLeftStart.Location = new System.Drawing.Point(3, 62);
            this.labelLeftStart.Name = "labelLeftStart";
            this.labelLeftStart.Size = new System.Drawing.Size(189, 29);
            this.labelLeftStart.TabIndex = 6;
            this.labelLeftStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelLeftEnd
            // 
            this.labelLeftEnd.AutoSize = true;
            this.labelLeftEnd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelLeftEnd.ForeColor = System.Drawing.Color.Black;
            this.labelLeftEnd.Location = new System.Drawing.Point(198, 62);
            this.labelLeftEnd.Name = "labelLeftEnd";
            this.labelLeftEnd.Size = new System.Drawing.Size(190, 29);
            this.labelLeftEnd.TabIndex = 7;
            this.labelLeftEnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelRightStart
            // 
            this.labelRightStart.AutoSize = true;
            this.labelRightStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelRightStart.Location = new System.Drawing.Point(3, 153);
            this.labelRightStart.Name = "labelRightStart";
            this.labelRightStart.Size = new System.Drawing.Size(189, 32);
            this.labelRightStart.TabIndex = 8;
            this.labelRightStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelRightEnd
            // 
            this.labelRightEnd.AutoSize = true;
            this.labelRightEnd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelRightEnd.Location = new System.Drawing.Point(198, 153);
            this.labelRightEnd.Name = "labelRightEnd";
            this.labelRightEnd.Size = new System.Drawing.Size(190, 32);
            this.labelRightEnd.TabIndex = 9;
            this.labelRightEnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WakeTimeBar
            // 
            this.WakeTimeBar.LargeChange = 1;
            this.WakeTimeBar.Location = new System.Drawing.Point(58, 35);
            this.WakeTimeBar.Maximum = 9;
            this.WakeTimeBar.Minimum = 6;
            this.WakeTimeBar.Name = "WakeTimeBar";
            this.WakeTimeBar.Size = new System.Drawing.Size(278, 45);
            this.WakeTimeBar.TabIndex = 4;
            this.WakeTimeBar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.WakeTimeBar.Value = 6;
            this.WakeTimeBar.ValueChanged += new System.EventHandler(this.WakeTimeBar_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(50, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 5;
            this.label8.Text = "6 am";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(134, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 19);
            this.label9.TabIndex = 6;
            this.label9.Text = "7 am";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(215, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 19);
            this.label10.TabIndex = 7;
            this.label10.Text = "8 am";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(301, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 19);
            this.label11.TabIndex = 8;
            this.label11.Text = "9 am";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.buttonGraph);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.WakeTimeBar);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(14, 211);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(399, 127);
            this.panel2.TabIndex = 9;
            // 
            // buttonGraph
            // 
            this.buttonGraph.Location = new System.Drawing.Point(138, 83);
            this.buttonGraph.Name = "buttonGraph";
            this.buttonGraph.Size = new System.Drawing.Size(120, 37);
            this.buttonGraph.TabIndex = 13;
            this.buttonGraph.Text = "Graph";
            this.buttonGraph.UseVisualStyleBackColor = true;
            this.buttonGraph.Click += new System.EventHandler(this.buttonGraph_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(301, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 19);
            this.label13.TabIndex = 12;
            this.label13.Text = "Night Owl";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 19);
            this.label12.TabIndex = 11;
            this.label12.Text = "Early Bird";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.moon;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(342, 36);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::OffsetChannelModulator.Properties.Resources.sun;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(14, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // CircadianSyncCheck
            // 
            this.CircadianSyncCheck.AutoSize = true;
            this.CircadianSyncCheck.Location = new System.Drawing.Point(14, 182);
            this.CircadianSyncCheck.Name = "CircadianSyncCheck";
            this.CircadianSyncCheck.Size = new System.Drawing.Size(144, 23);
            this.CircadianSyncCheck.TabIndex = 11;
            this.CircadianSyncCheck.Text = "Circadian Sync";
            this.CircadianSyncCheck.UseVisualStyleBackColor = true;
            this.CircadianSyncCheck.CheckedChanged += new System.EventHandler(this.CircadianSyncCheck_CheckedChanged);
            // 
            // StreamingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 716);
            this.Controls.Add(this.CircadianSyncCheck);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonOpenConverter);
            this.Controls.Add(this.buttonOpenFiles);
            this.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "StreamingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Offset Streaming";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StreamingForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WakeTimeBar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOpenFiles;
        private System.Windows.Forms.Button buttonOpenConverter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.RadioButton radioButtonLeftEar;
        private System.Windows.Forms.RadioButton radioButtonRightEar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button buttonPlayRandom;
        private System.Windows.Forms.Button buttonPlayPrev;
        private System.Windows.Forms.Button buttonPlayPause;
        private System.Windows.Forms.Button buttonPlayNext;
        private System.Windows.Forms.Button buttonPlayRepeat;
        private System.Windows.Forms.Label labelAlbum;
        private System.Windows.Forms.Label labelSong;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonPlaylist;
        private System.Windows.Forms.Label labelLeftStart;
        private System.Windows.Forms.Label labelLeftEnd;
        private System.Windows.Forms.Label labelRightStart;
        private System.Windows.Forms.Label labelRightEnd;
        private System.Windows.Forms.TrackBar WakeTimeBar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox CircadianSyncCheck;
        private System.Windows.Forms.Button buttonGraph;
    }
}