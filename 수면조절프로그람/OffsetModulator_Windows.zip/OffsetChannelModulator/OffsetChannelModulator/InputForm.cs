﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OffsetChannelModulator
{
    public partial class InputForm : Form
    {
        public string ProfileName = "";
        public InputForm()
        {
            InitializeComponent();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            if (textBoxProfileName.Text.Trim() == "")
            {
                MessageBox.Show("Profile name is empty.", "Profile name", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            this.DialogResult = DialogResult.OK;
            ProfileName = textBoxProfileName.Text.Trim();
            Hide();
        }

        private void textBoxProfileName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
            {
                if (textBoxProfileName.Text.Trim() == "")
                {
                    MessageBox.Show("Profile name is empty.", "Profile name", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                e.Handled = true;
                this.DialogResult = DialogResult.OK;
                ProfileName = textBoxProfileName.Text.Trim();
                Hide();
            }
        }
    }
}
