﻿namespace OffsetChannelModulator
{
    partial class ConvertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOpenFiles = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxProfile = new System.Windows.Forms.ComboBox();
            this.buttonCreateProfile = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.leftChannelOffset = new System.Windows.Forms.NumericUpDown();
            this.checkBoxRandomLeft = new System.Windows.Forms.CheckBox();
            this.leftCustomMin = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.leftCustomMax = new System.Windows.Forms.NumericUpDown();
            this.rightCustomMax = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.rightCustomMin = new System.Windows.Forms.NumericUpDown();
            this.checkBoxRandomRight = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.rightChannelOffset = new System.Windows.Forms.NumericUpDown();
            this.buttonExport = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonLeft = new System.Windows.Forms.RadioButton();
            this.radioButtonRight = new System.Windows.Forms.RadioButton();
            this.RightChannelControlPanel = new System.Windows.Forms.Panel();
            this.LeftChannelControlPanel = new System.Windows.Forms.Panel();
            this.labelExportFolder = new System.Windows.Forms.Label();
            this.buttonExportFolder = new System.Windows.Forms.Button();
            this.labelFileLoadStatus = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonRemoveProfile = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.leftChannelOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftCustomMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftCustomMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightCustomMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightCustomMin)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rightChannelOffset)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.RightChannelControlPanel.SuspendLayout();
            this.LeftChannelControlPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonOpenFiles
            // 
            this.buttonOpenFiles.BackColor = System.Drawing.Color.White;
            this.buttonOpenFiles.CausesValidation = false;
            this.buttonOpenFiles.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonOpenFiles.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonOpenFiles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenFiles.Location = new System.Drawing.Point(14, 11);
            this.buttonOpenFiles.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonOpenFiles.Name = "buttonOpenFiles";
            this.buttonOpenFiles.Size = new System.Drawing.Size(148, 41);
            this.buttonOpenFiles.TabIndex = 1;
            this.buttonOpenFiles.Text = "Open Files";
            this.buttonOpenFiles.UseVisualStyleBackColor = false;
            this.buttonOpenFiles.Click += new System.EventHandler(this.buttonOpenFiles_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 64);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select a profile";
            // 
            // comboBoxProfile
            // 
            this.comboBoxProfile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProfile.FormattingEnabled = true;
            this.comboBoxProfile.Location = new System.Drawing.Point(14, 85);
            this.comboBoxProfile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBoxProfile.Name = "comboBoxProfile";
            this.comboBoxProfile.Size = new System.Drawing.Size(222, 27);
            this.comboBoxProfile.TabIndex = 4;
            this.comboBoxProfile.SelectedIndexChanged += new System.EventHandler(this.comboBoxProfile_SelectedIndexChanged);
            // 
            // buttonCreateProfile
            // 
            this.buttonCreateProfile.BackColor = System.Drawing.Color.White;
            this.buttonCreateProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonCreateProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonCreateProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateProfile.Location = new System.Drawing.Point(244, 74);
            this.buttonCreateProfile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonCreateProfile.Name = "buttonCreateProfile";
            this.buttonCreateProfile.Size = new System.Drawing.Size(83, 48);
            this.buttonCreateProfile.TabIndex = 5;
            this.buttonCreateProfile.Text = "Create Profile";
            this.buttonCreateProfile.UseVisualStyleBackColor = false;
            this.buttonCreateProfile.Click += new System.EventHandler(this.buttonCreateProfile_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(400, 43);
            this.panel1.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.leftChannelOffset, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 5);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(388, 31);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(4, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "Left Channel";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // leftChannelOffset
            // 
            this.leftChannelOffset.Location = new System.Drawing.Point(198, 3);
            this.leftChannelOffset.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.leftChannelOffset.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.leftChannelOffset.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.leftChannelOffset.Name = "leftChannelOffset";
            this.leftChannelOffset.Size = new System.Drawing.Size(94, 26);
            this.leftChannelOffset.TabIndex = 3;
            this.leftChannelOffset.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // checkBoxRandomLeft
            // 
            this.checkBoxRandomLeft.AutoSize = true;
            this.checkBoxRandomLeft.Location = new System.Drawing.Point(5, 50);
            this.checkBoxRandomLeft.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBoxRandomLeft.Name = "checkBoxRandomLeft";
            this.checkBoxRandomLeft.Size = new System.Drawing.Size(155, 23);
            this.checkBoxRandomLeft.TabIndex = 7;
            this.checkBoxRandomLeft.Text = "Randomize Start";
            this.checkBoxRandomLeft.UseVisualStyleBackColor = true;
            // 
            // leftCustomMin
            // 
            this.leftCustomMin.Location = new System.Drawing.Point(168, 78);
            this.leftCustomMin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.leftCustomMin.Maximum = new decimal(new int[] {
            998,
            0,
            0,
            0});
            this.leftCustomMin.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.leftCustomMin.Name = "leftCustomMin";
            this.leftCustomMin.Size = new System.Drawing.Size(65, 26);
            this.leftCustomMin.TabIndex = 8;
            this.leftCustomMin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(234, 80);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 19);
            this.label7.TabIndex = 10;
            this.label7.Text = ":";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 80);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 19);
            this.label8.TabIndex = 11;
            this.label8.Text = "Custom Range";
            // 
            // leftCustomMax
            // 
            this.leftCustomMax.Location = new System.Drawing.Point(248, 78);
            this.leftCustomMax.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.leftCustomMax.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.leftCustomMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.leftCustomMax.Name = "leftCustomMax";
            this.leftCustomMax.Size = new System.Drawing.Size(65, 26);
            this.leftCustomMax.TabIndex = 12;
            this.leftCustomMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // rightCustomMax
            // 
            this.rightCustomMax.Location = new System.Drawing.Point(248, 83);
            this.rightCustomMax.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rightCustomMax.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.rightCustomMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.rightCustomMax.Name = "rightCustomMax";
            this.rightCustomMax.Size = new System.Drawing.Size(65, 26);
            this.rightCustomMax.TabIndex = 18;
            this.rightCustomMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 85);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 19);
            this.label9.TabIndex = 17;
            this.label9.Text = "Custom Range";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(234, 85);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 19);
            this.label10.TabIndex = 16;
            this.label10.Text = ":";
            // 
            // rightCustomMin
            // 
            this.rightCustomMin.Location = new System.Drawing.Point(168, 83);
            this.rightCustomMin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rightCustomMin.Maximum = new decimal(new int[] {
            998,
            0,
            0,
            0});
            this.rightCustomMin.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.rightCustomMin.Name = "rightCustomMin";
            this.rightCustomMin.Size = new System.Drawing.Size(65, 26);
            this.rightCustomMin.TabIndex = 15;
            this.rightCustomMin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // checkBoxRandomRight
            // 
            this.checkBoxRandomRight.AutoSize = true;
            this.checkBoxRandomRight.Location = new System.Drawing.Point(5, 59);
            this.checkBoxRandomRight.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBoxRandomRight.Name = "checkBoxRandomRight";
            this.checkBoxRandomRight.Size = new System.Drawing.Size(155, 23);
            this.checkBoxRandomRight.TabIndex = 14;
            this.checkBoxRandomRight.Text = "Randomize Start";
            this.checkBoxRandomRight.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Location = new System.Drawing.Point(0, 5);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(400, 44);
            this.panel2.TabIndex = 13;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.rightChannelOffset, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 5);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(388, 32);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(4, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(186, 32);
            this.label11.TabIndex = 0;
            this.label11.Text = "Right Channel";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rightChannelOffset
            // 
            this.rightChannelOffset.Location = new System.Drawing.Point(198, 3);
            this.rightChannelOffset.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rightChannelOffset.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.rightChannelOffset.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.rightChannelOffset.Name = "rightChannelOffset";
            this.rightChannelOffset.Size = new System.Drawing.Size(94, 26);
            this.rightChannelOffset.TabIndex = 3;
            this.rightChannelOffset.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonExport
            // 
            this.buttonExport.BackColor = System.Drawing.Color.White;
            this.buttonExport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonExport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExport.Location = new System.Drawing.Point(219, 487);
            this.buttonExport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonExport.Name = "buttonExport";
            this.buttonExport.Size = new System.Drawing.Size(194, 34);
            this.buttonExport.TabIndex = 19;
            this.buttonExport.Text = "Export";
            this.buttonExport.UseVisualStyleBackColor = false;
            this.buttonExport.Click += new System.EventHandler(this.buttonExport_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Location = new System.Drawing.Point(14, 123);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox1.Size = new System.Drawing.Size(400, 61);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Channel Selection";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.radioButtonLeft, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonRight, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(5, 24);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(390, 32);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // radioButtonLeft
            // 
            this.radioButtonLeft.AutoSize = true;
            this.radioButtonLeft.Checked = true;
            this.radioButtonLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLeft.Location = new System.Drawing.Point(4, 3);
            this.radioButtonLeft.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonLeft.Name = "radioButtonLeft";
            this.radioButtonLeft.Size = new System.Drawing.Size(187, 26);
            this.radioButtonLeft.TabIndex = 0;
            this.radioButtonLeft.TabStop = true;
            this.radioButtonLeft.Text = "Left Channel";
            this.radioButtonLeft.UseVisualStyleBackColor = true;
            this.radioButtonLeft.CheckedChanged += new System.EventHandler(this.radioButtonLeft_CheckedChanged);
            // 
            // radioButtonRight
            // 
            this.radioButtonRight.AutoSize = true;
            this.radioButtonRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRight.Location = new System.Drawing.Point(199, 3);
            this.radioButtonRight.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonRight.Name = "radioButtonRight";
            this.radioButtonRight.Size = new System.Drawing.Size(187, 26);
            this.radioButtonRight.TabIndex = 1;
            this.radioButtonRight.Text = "Right Channel";
            this.radioButtonRight.UseVisualStyleBackColor = true;
            this.radioButtonRight.CheckedChanged += new System.EventHandler(this.radioButtonRight_CheckedChanged);
            // 
            // RightChannelControlPanel
            // 
            this.RightChannelControlPanel.Controls.Add(this.checkBoxRandomRight);
            this.RightChannelControlPanel.Controls.Add(this.rightCustomMin);
            this.RightChannelControlPanel.Controls.Add(this.panel2);
            this.RightChannelControlPanel.Controls.Add(this.rightCustomMax);
            this.RightChannelControlPanel.Controls.Add(this.label10);
            this.RightChannelControlPanel.Controls.Add(this.label9);
            this.RightChannelControlPanel.Enabled = false;
            this.RightChannelControlPanel.Location = new System.Drawing.Point(14, 311);
            this.RightChannelControlPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.RightChannelControlPanel.Name = "RightChannelControlPanel";
            this.RightChannelControlPanel.Size = new System.Drawing.Size(400, 120);
            this.RightChannelControlPanel.TabIndex = 21;
            // 
            // LeftChannelControlPanel
            // 
            this.LeftChannelControlPanel.Controls.Add(this.panel1);
            this.LeftChannelControlPanel.Controls.Add(this.checkBoxRandomLeft);
            this.LeftChannelControlPanel.Controls.Add(this.leftCustomMin);
            this.LeftChannelControlPanel.Controls.Add(this.leftCustomMax);
            this.LeftChannelControlPanel.Controls.Add(this.label7);
            this.LeftChannelControlPanel.Controls.Add(this.label8);
            this.LeftChannelControlPanel.Location = new System.Drawing.Point(14, 190);
            this.LeftChannelControlPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.LeftChannelControlPanel.Name = "LeftChannelControlPanel";
            this.LeftChannelControlPanel.Size = new System.Drawing.Size(400, 115);
            this.LeftChannelControlPanel.TabIndex = 22;
            // 
            // labelExportFolder
            // 
            this.labelExportFolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelExportFolder.Location = new System.Drawing.Point(14, 443);
            this.labelExportFolder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelExportFolder.Name = "labelExportFolder";
            this.labelExportFolder.Size = new System.Drawing.Size(348, 32);
            this.labelExportFolder.TabIndex = 23;
            this.labelExportFolder.Text = "No folder selected";
            this.labelExportFolder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonExportFolder
            // 
            this.buttonExportFolder.BackColor = System.Drawing.Color.White;
            this.buttonExportFolder.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonExportFolder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonExportFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportFolder.Location = new System.Drawing.Point(375, 442);
            this.buttonExportFolder.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonExportFolder.Name = "buttonExportFolder";
            this.buttonExportFolder.Size = new System.Drawing.Size(39, 33);
            this.buttonExportFolder.TabIndex = 24;
            this.buttonExportFolder.Text = "...";
            this.buttonExportFolder.UseVisualStyleBackColor = false;
            this.buttonExportFolder.Click += new System.EventHandler(this.buttonExportFolder_Click);
            // 
            // labelFileLoadStatus
            // 
            this.labelFileLoadStatus.Location = new System.Drawing.Point(176, 11);
            this.labelFileLoadStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelFileLoadStatus.Name = "labelFileLoadStatus";
            this.labelFileLoadStatus.Size = new System.Drawing.Size(198, 41);
            this.labelFileLoadStatus.TabIndex = 25;
            this.labelFileLoadStatus.Text = "0 files loaded";
            this.labelFileLoadStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.White;
            this.buttonBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Location = new System.Drawing.Point(14, 487);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 34);
            this.buttonBack.TabIndex = 26;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonRemoveProfile
            // 
            this.buttonRemoveProfile.BackColor = System.Drawing.Color.White;
            this.buttonRemoveProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonRemoveProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonRemoveProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRemoveProfile.Location = new System.Drawing.Point(331, 74);
            this.buttonRemoveProfile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonRemoveProfile.Name = "buttonRemoveProfile";
            this.buttonRemoveProfile.Size = new System.Drawing.Size(83, 48);
            this.buttonRemoveProfile.TabIndex = 27;
            this.buttonRemoveProfile.Text = "Remove Profile";
            this.buttonRemoveProfile.UseVisualStyleBackColor = false;
            this.buttonRemoveProfile.Click += new System.EventHandler(this.buttonRemoveProfile_Click);
            // 
            // ConvertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 531);
            this.Controls.Add(this.buttonRemoveProfile);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.labelFileLoadStatus);
            this.Controls.Add(this.buttonExportFolder);
            this.Controls.Add(this.labelExportFolder);
            this.Controls.Add(this.LeftChannelControlPanel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonExport);
            this.Controls.Add(this.buttonCreateProfile);
            this.Controls.Add(this.comboBoxProfile);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonOpenFiles);
            this.Controls.Add(this.RightChannelControlPanel);
            this.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "ConvertForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Convert Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ConvertForm_FormClosed);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.leftChannelOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftCustomMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftCustomMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightCustomMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightCustomMin)).EndInit();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rightChannelOffset)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.RightChannelControlPanel.ResumeLayout(false);
            this.RightChannelControlPanel.PerformLayout();
            this.LeftChannelControlPanel.ResumeLayout(false);
            this.LeftChannelControlPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOpenFiles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxProfile;
        private System.Windows.Forms.Button buttonCreateProfile;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown leftChannelOffset;
        private System.Windows.Forms.CheckBox checkBoxRandomLeft;
        private System.Windows.Forms.NumericUpDown leftCustomMin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown leftCustomMax;
        private System.Windows.Forms.NumericUpDown rightCustomMax;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown rightCustomMin;
        private System.Windows.Forms.CheckBox checkBoxRandomRight;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown rightChannelOffset;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton radioButtonLeft;
        private System.Windows.Forms.RadioButton radioButtonRight;
        private System.Windows.Forms.Panel RightChannelControlPanel;
        private System.Windows.Forms.Panel LeftChannelControlPanel;
        private System.Windows.Forms.Label labelExportFolder;
        private System.Windows.Forms.Button buttonExportFolder;
        private System.Windows.Forms.Label labelFileLoadStatus;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonRemoveProfile;
    }
}