﻿using NAudio.MediaFoundation;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OffsetChannelModulator
{
    public partial class StreamingForm : Form
    {
        List<string> FileList = new List<string>();
        bool IsLeft = true; //left channel offset?
        int Offset = 0;
        private WaveOutEvent outputDevice;
        private MyAudioFileReader audioFile;
        bool IsPlaying = false;
        bool IsFormClosing = false;
        bool IsPaused = true;
        bool IsStopped = false;
        List<string> PlayList = new List<string>();
        int currentIndex = 0;

        int RepeatMode = 0; //No repeat, 1-repeat one, 2- repeat all
        bool IsShuffling = false;

        string CurrentSong = "";

        public StreamingForm()
        {
            InitializeComponent();
            //Font = Utility.GlobalFont;
            labelLeftStart.ForeColor = Color.FromArgb(255, 81, 158, 71);
            labelLeftEnd.ForeColor = Color.FromArgb(255, 81, 158, 71);
        }

        private void buttonPlayRandom_Click(object sender, EventArgs e)
        {
            if (IsShuffling)
            {
                IsShuffling = false;
                buttonPlayRandom.BackgroundImage = Properties.Resources.suffle_off;
            }
            else
            {
                IsShuffling = true;
                buttonPlayRandom.BackgroundImage = Properties.Resources.suffle_on;
            }
        }

        private void buttonOpenFiles_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "music files (*.mp3, *.flac, *.wav)|*.mp3;*.flac;*.wav";
            openFileDialog.Title = "Select music files";
            openFileDialog.Multiselect = true;
            DialogResult result = openFileDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                FileList = new List<string>();
                foreach (var s in openFileDialog.FileNames)
                {
                    if (!Utility.CheckMono(s)) //Filter out mono channel files from streaming
                        FileList.Add(s);
                }
                UpdatePlaylist();
            }
        }

        private void buttonPlaylist_Click(object sender, EventArgs e)
        {
            PlayListForm playListForm = new PlayListForm(FileList);
            playListForm.ShowDialog(this);
        }

        private void radioButtonLeftEar_CheckedChanged(object sender, EventArgs e)
        {
            IsLeft = radioButtonLeftEar.Checked;
            if (IsLeft)
            {
                labelLeftStart.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelLeftEnd.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelRightStart.ForeColor = Color.Black;
                labelRightEnd.ForeColor = Color.Black;
            }
            else
            {
                labelLeftStart.ForeColor = Color.Black;
                labelLeftEnd.ForeColor = Color.Black;
                labelRightStart.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelRightEnd.ForeColor = Color.FromArgb(255, 81, 158, 71);
            }
        }

        private void radioButtonRightEar_CheckedChanged(object sender, EventArgs e)
        {
            IsLeft = radioButtonLeftEar.Checked;
            if (IsLeft)
            {
                labelLeftStart.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelLeftEnd.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelRightStart.ForeColor = Color.Black;
                labelRightEnd.ForeColor = Color.Black;
            }
            else
            {
                labelLeftStart.ForeColor = Color.Black;
                labelLeftEnd.ForeColor = Color.Black;
                labelRightStart.ForeColor = Color.FromArgb(255, 81, 158, 71);
                labelRightEnd.ForeColor = Color.FromArgb(255, 81, 158, 71);
            }

            IsPaused = false;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }
            currentIndex--;

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }

        private void DisplaySongInfo()
        {
            if (PlayList.Count == 0 || CurrentSong == "") return;
            using (FileStream fs = File.OpenRead(CurrentSong))
            {
                if (fs.Length >= 128)
                {
                    MusicID3Tag tag = new MusicID3Tag();
                    fs.Seek(-128, SeekOrigin.End);
                    fs.Read(tag.TAGID, 0, tag.TAGID.Length);
                    fs.Read(tag.Title, 0, tag.Title.Length);
                    fs.Read(tag.Artist, 0, tag.Artist.Length);
                    fs.Read(tag.Album, 0, tag.Album.Length);
                    fs.Read(tag.Year, 0, tag.Year.Length);
                    fs.Read(tag.Comment, 0, tag.Comment.Length);
                    fs.Read(tag.Genre, 0, tag.Genre.Length);
                    string theTAGID = Encoding.Default.GetString(tag.TAGID);

                    if (theTAGID.Equals("TAG"))
                    {
                        string Title = Encoding.Default.GetString(tag.Title);
                        string Artist = Encoding.Default.GetString(tag.Artist);
                        string Album = Encoding.Default.GetString(tag.Album);
                        string Year = Encoding.Default.GetString(tag.Year);
                        string Comment = Encoding.Default.GetString(tag.Comment);
                        string Genre = Encoding.Default.GetString(tag.Genre);

                        labelSong.Text = Title;
                        labelAlbum.Text = Album;
                    }
                    else
                    {
                        labelSong.Text = "Unknown";
                        labelAlbum.Text = "Unknown";
                    }
                }
            }
            //Update Timecode information
            labelLeftStart.Text = GetStartTimecode(true);
            labelLeftEnd.Text = GetEndTimecode(true);
            labelRightStart.Text = GetStartTimecode(false);
            labelRightEnd.Text = GetEndTimecode(false);
        }

        private void UpdatePlaylist()
        {//This will be different based on the shuffle setting
            Stop();
            PlayList.Clear();
            foreach (var f in FileList)
            {
                PlayList.Add(f);
            }
        }

        private void buttonPlayPause_Click(object sender, EventArgs e)
        {
            Play();
        }

        private void Play()
        {
            if (PlayList.Count == 0) return;
            if (audioFile == null)
            {
                GetCurrentSong();
                if (CurrentSong == "")
                {
                    Stop();
                    return;
                }
                Offset = Utility.GenerateOffset(CurrentSong, CircadianSyncCheck.Checked, WakeTimeBar.Value);
                audioFile = new MyAudioFileReader(CurrentSong, Offset, IsLeft);
            }
            if (outputDevice == null)
            {
                outputDevice = new WaveOutEvent();
                outputDevice.PlaybackStopped += OnPlaybackStopped;
                outputDevice.Init(audioFile);
            }
            if (IsPlaying)
            {
                outputDevice.Stop();
                IsPlaying = false;
                IsPaused = true;
                //Change Icon of the button to play icon
                buttonPlayPause.BackgroundImage = Properties.Resources.play;
            }
            else
            {
                IsStopped = false;
                outputDevice.Play();
                IsPlaying = true;
                IsPaused = false;
                //Change icon the button to pause icon
                buttonPlayPause.BackgroundImage = Properties.Resources.pause;
            }
            //Display Song info
            DisplaySongInfo();
        }

        private void Stop()
        {
            IsPaused = false;
            IsStopped = true;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }

        private void OnPlaybackStopped(object sender, StoppedEventArgs args)
        {
            if (IsFormClosing)
            {
                outputDevice.Dispose();
                outputDevice = null;
                audioFile.Dispose();
                audioFile = null;
                IsFormClosing = false;
            }
            else
            {
                if (IsPaused)
                {//If this is pause, do nothing

                }
                else
                {//If the music ended naturally, play next song in the queue
                    IsPlaying = false;
                    if (RepeatMode == 1)
                    {
                        buttonPlayPause.BackgroundImage = Properties.Resources.play;
                    }
                    else if (RepeatMode == 0 || RepeatMode == 2)
                    {
                        if (!IsShuffling)
                            currentIndex++;
                    }
                    if (audioFile != null)
                    {
                        audioFile.Dispose();
                    }
                    audioFile = null;
                    if (outputDevice != null)
                    {
                        outputDevice.Dispose();
                    }
                    outputDevice = null;
                    if (!IsStopped)
                        Play();
                }
            }
        }

        private void StreamingForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            IsFormClosing = true;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }
        }

        private void GetCurrentSong()
        {
            if (IsShuffling && RepeatMode != 1)
            {
                Random random = new Random((int)DateTime.Now.TimeOfDay.TotalMilliseconds);
                currentIndex = random.Next(0, PlayList.Count);
                CurrentSong = PlayList[currentIndex];
            }

            if (currentIndex < 0)
            {
                if (RepeatMode == 0)
                {
                    currentIndex = 0;
                    CurrentSong = "";
                    return;
                }
                else if (RepeatMode == 2)
                {
                    currentIndex = PlayList.Count - 1;
                }
                else
                {
                    currentIndex = 0;
                }
            }
            else if (currentIndex >= PlayList.Count)
            {
                if (RepeatMode == 0)
                {
                    currentIndex = PlayList.Count - 1;
                    CurrentSong = "";
                    return;
                }
                else if (RepeatMode == 2)
                {
                    currentIndex = 0;
                }
                else
                {
                    currentIndex = PlayList.Count - 1;
                }
            }
            CurrentSong = PlayList[currentIndex];
        }

        private string GetStartTimecode(bool isleft)
        {
            if (audioFile == null)
            {
                return "00:00:00.00000";
            }
            if (isleft == audioFile.IsLeft)
            {
                //need to display offset starttimecode
                int offset = audioFile.OffsetTime;
                return AssembleTimecode(TimeSpan.FromTicks(offset * 100));
            }
            else
            {
                return "00:00:00.00000";
            }
        }

        private string GetEndTimecode(bool isleft)
        {
            if (audioFile == null)
            {
                return "00:00:00.00000";
            }
            TimeSpan duration = audioFile.GetDuration();
            if (isleft == audioFile.IsLeft)
            {
                int offset = audioFile.OffsetTime;
                return AssembleTimecode(duration.Add(TimeSpan.FromTicks(offset * 100)));
            }
            else
            {
                return AssembleTimecode(duration);
            }
        }

        private string AssembleTimecode(TimeSpan timeSpan)
        {
            if (timeSpan == null)
            {
                return "00:00:00.00000";
            }
            else
            {
                string timecode = timeSpan.ToString("G");
                return timecode.Substring(2, timecode.Length - 4);
            }
        }

        private void buttonPlayRepeat_Click(object sender, EventArgs e)
        {
            if (RepeatMode == 0)
            {
                RepeatMode = 1;
                buttonPlayRepeat.BackgroundImage = Properties.Resources.repeat_one;
            }
            else if (RepeatMode == 1)
            {
                RepeatMode = 2;
                buttonPlayRepeat.BackgroundImage = Properties.Resources.repeat_all;
            }
            else if (RepeatMode == 2)
            {
                RepeatMode = 0;
                buttonPlayRepeat.BackgroundImage = Properties.Resources.repeat_off;
            }
        }

        private void buttonPlayNext_Click(object sender, EventArgs e)
        {
            IsPaused = false;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }

        private void buttonPlayPrev_Click(object sender, EventArgs e)
        {
            if (RepeatMode != 1)
            {
                currentIndex -= 2;
            }
            IsPaused = false;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }

        private void buttonOpenConverter_Click(object sender, EventArgs e)
        {
            IsFormClosing = true;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }
            IsPlaying = false;

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
            ConvertForm convertForm = new ConvertForm(this);
            convertForm.Show();
            Hide();
        }

        private void CircadianSyncCheck_CheckedChanged(object sender, EventArgs e)
        {
            IsPaused = false;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }
            currentIndex--;

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }

        private void buttonGraph_Click(object sender, EventArgs e)
        {
            ChartForm chartForm = new ChartForm(WakeTimeBar.Value, CurrentSong);
            chartForm.ShowDialog(this);
        }

        private void WakeTimeBar_ValueChanged(object sender, EventArgs e)
        {
            if (!CircadianSyncCheck.Checked) return;
            IsPaused = false;
            if (outputDevice != null)
            {
                outputDevice.Stop();
            }
            currentIndex--;

            buttonPlayPause.BackgroundImage = Properties.Resources.play;
        }
    }

    class MusicID3Tag
    {
        public byte[] TAGID = new byte[3];      //  3
        public byte[] Title = new byte[30];     //  30
        public byte[] Artist = new byte[30];    //  30 
        public byte[] Album = new byte[30];     //  30 
        public byte[] Year = new byte[4];       //  4 
        public byte[] Comment = new byte[30];   //  30 
        public byte[] Genre = new byte[1];      //  1
    }
}
