package com.songhku925.offsetmodulator

import android.net.Uri

interface ServiceCallbacks {
    fun updatePlayStatus(playList: ArrayList<String>, currentIndex: Int, isPlaying: Boolean)
    fun updateOffsetStatus(channelNo: Int, offset: Int)
    fun setOffsetSettings()
}