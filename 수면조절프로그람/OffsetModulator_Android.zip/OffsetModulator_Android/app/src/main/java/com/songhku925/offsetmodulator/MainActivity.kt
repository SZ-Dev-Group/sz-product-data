package com.songhku925.offsetmodulator

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import co.metalab.asyncawait.async
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream


private const val REQUEST_CODE = 10
private val neededPermissions = arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)


class MainActivity : AppCompatActivity(), ServiceCallbacks {

    lateinit var buttonAddMusic: Button
    lateinit var progressBar: ProgressBar
    lateinit var buttonClearList: Button
    lateinit var buttonMusicList: Button
    lateinit var radioButtonLeft: RadioButton
    lateinit var radioButtonRight: RadioButton
    lateinit var checkboxCircadian: CheckBox
    lateinit var spinnerWakeupTime: Spinner
    lateinit var textViewArtist: TextView
    lateinit var textviewTitle: TextView
    lateinit var buttonPlay: ImageButton
    lateinit var buttonNext: ImageButton
    lateinit var buttonPrev: ImageButton
    lateinit var buttonShuffle: ImageButton
    lateinit var buttonRepeat: ImageButton
    lateinit var spinnerMusic: Spinner


    var musicPlayService: MusicPlayService? = null
    var isBound = false
    var spinnerOpened = false

    private var playList: ArrayList<Uri>? = null
    private var playFileList: ArrayList<String>? = null


    private val musicServiceConnection = object : ServiceConnection {
        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
        }

        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicPlayService.MyLocalBinder
            musicPlayService = binder.getService()
            isBound = true
            musicPlayService!!.setServiceCallbacks(this@MainActivity)
            //Update play status when this activity is recreated
            if (musicPlayService != null) {
                try {
                    //get variables from intent
                    val shuffle = musicPlayService!!.shuffle
                    val repeat = musicPlayService!!.repeat
                    val channel = musicPlayService!!.channelNo
                    val offset = musicPlayService!!.offset
                    val isPlaying = musicPlayService!!.isPlaying
                    val wakeUpTime = musicPlayService!!.wakeUpTime
                    val circadian = musicPlayService!!.circadian

                    this@MainActivity.playFileList = musicPlayService!!.playList

                    if (this@MainActivity.playFileList == null) {
                        this@MainActivity.playFileList = ArrayList()
                    }
                    if (this@MainActivity.playList == null) {
                        this@MainActivity.playList = ArrayList()
                    }

//                    if (musicPlayService!!.playList != null) {
//                        this@MainActivity.playFileList = arrayListOf()
//                        for (i in musicPlayService!!.playList!!) {
//                            this@MainActivity.playFileList!!.add(i)
//                        }
//                    }

                    this@MainActivity.updatePlayList()

                    if (shuffle == 1) buttonShuffle.setImageResource(R.drawable.suffle_on)
                    else buttonShuffle.setImageResource(R.drawable.suffle_off)
                    when (repeat) {
                        0 -> buttonRepeat.setImageResource(R.drawable.repeat_off)
                        1 -> buttonRepeat.setImageResource(R.drawable.repeat_one)
                        2 -> buttonRepeat.setImageResource(R.drawable.repeat_all)
                    }
                    if (channel == 0) {
                        textViewLeftOffset.text = "$offset"
                        textViewRightOffset.text = "0"
                        radioButtonLeft.isChecked = false
                        radioButtonRight.isChecked = true
                    } else {
                        textViewLeftOffset.text = "0"
                        textViewRightOffset.text = "$offset"
                        radioButtonLeft.isChecked = true
                        radioButtonRight.isChecked = false
                    }
                    if (isPlaying) buttonPlay.setImageResource(R.drawable.pause)
                    else buttonPlay.setImageResource(R.drawable.play)
                    spinnerWakeupTime.setSelection(musicPlayService!!.wakeUpTime - 6)
                    Log.d("wakeuptime", musicPlayService!!.wakeUpTime.toString())
                    checkboxCircadian.isChecked = circadian

                    updateMusicInfo(musicPlayService!!.currentIndex)
                } catch (e: java.lang.Exception) {

                }
            }

        }

    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            supportActionBar?.hide()
        } catch (e: Exception) {
        }

        setContentView(R.layout.activity_main)

        checkPermission()

//        //clear externalMediaDir content
//        try {
//            externalMediaDirs.first().deleteRecursively()
//        } catch (e: java.lang.Exception){}

        buttonAddMusic = findViewById(R.id.buttonAddMusic)
        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = View.GONE
        buttonClearList = findViewById(R.id.buttonClearList)
        buttonMusicList = findViewById(R.id.buttonMusicList)
        radioButtonLeft = findViewById(R.id.radioButtonLeft)
        radioButtonRight = findViewById(R.id.radioButtonRight)
        checkboxCircadian = findViewById(R.id.checkBoxCircadian)
        spinnerWakeupTime = findViewById(R.id.spinnerWakeupTime)
        textViewArtist = findViewById(R.id.textViewArtist)
        textviewTitle = findViewById(R.id.textViewTitle)
        buttonPlay = findViewById(R.id.imageButtonPlay)
        buttonNext = findViewById(R.id.imageButtonNext)
        buttonPrev = findViewById(R.id.imageButtonPrev)
        buttonShuffle = findViewById(R.id.imageButtonShuffle)
        buttonRepeat = findViewById(R.id.imageButtonRepeat)
        spinnerMusic = findViewById(R.id.spinnerMusic)

        textViewTitle.isSelected = true

        buttonAddMusic.setOnClickListener {
            val filesIntent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            filesIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            filesIntent.addCategory(Intent.CATEGORY_OPENABLE)
            filesIntent.type = "audio/*" //use image/* for photos, etc.

            startActivityForResult(filesIntent, 1001)
        }

        buttonClearList.setOnClickListener {
            val builder = AlertDialog.Builder(this@MainActivity)
            // Set the alert dialog title
            builder.setTitle("Clear playlist")
                .setMessage("Are you sure to clear the playlist?")
                .setPositiveButton("YES") { dialog, which ->
                    // Do something when user press the positive button
                    buttonClearList.isEnabled = false
                    async {
                        await { externalMediaDirs.first().deleteRecursively() }
                        buttonPlay.setImageResource(R.drawable.play)
                        this@MainActivity.playFileList = ArrayList()
                        this@MainActivity.playList = ArrayList()
                        updatePlayList()
                        textViewTitle.text = "Unknown Title"
                        textViewArtist.text = "Unknown Artist"
                        buttonClearList.isEnabled = true
                    }
                }.setNegativeButton("No") { dialog, which ->

                }
            // Finally, make the alert dialog using builder
            val dialog: AlertDialog = builder.create()
            // Display the alert dialog on app interface
            dialog.show()
        }

        buttonMusicList.setOnClickListener {
            spinnerMusic.performClick()
            spinnerOpened = true
        }

        buttonPlay.setOnClickListener {
            if (musicPlayService != null && playFileList != null) {
                if (playFileList!!.count() == 0) {
                    buttonPlay.setImageResource(R.drawable.play)
                } else {
                    if (!musicPlayService!!.isPlaying) {
                        if (musicPlayService!!.isPaused) {
                            musicPlayService!!.pauseResume()
                        } else {
                            setOffsetSettings()
                            musicPlayService!!.play()
                        }
                        buttonPlay.setImageResource(R.drawable.pause)
                    } else {
                        musicPlayService!!.pauseResume()
                        musicPlayService!!.isResuming = true
                        buttonPlay.setImageResource(R.drawable.play)
                    }
                }
            } else {
                buttonPlay.setImageResource(R.drawable.play)
            }
        }

        buttonNext.setOnClickListener {
            if (musicPlayService != null && playFileList != null && playFileList!!.count() != 0) {

                if (musicPlayService?.playNextMusic()!!) {
                    buttonPlay.setImageResource(R.drawable.pause)
                } else {
                    buttonPlay.setImageResource(R.drawable.play)
                }
            }
        }

        buttonPrev.setOnClickListener {
            if (musicPlayService != null && playFileList != null && playFileList!!.count() != 0) {

                if (musicPlayService?.playPrevMusic()!!) {
                    buttonPlay.setImageResource(R.drawable.pause)
                } else {
                    buttonPlay.setImageResource(R.drawable.play)
                }
            }
        }

        buttonShuffle.setOnClickListener {
            if (musicPlayService != null) {
                if (musicPlayService!!.shuffle == 0) {
                    musicPlayService!!.shuffle = 1
                    buttonShuffle.setImageResource(R.drawable.suffle_on)
                    musicPlayService!!.repeat = 2
                    buttonRepeat.setImageResource(R.drawable.repeat_all)
                } else {
                    musicPlayService!!.shuffle = 0
                    buttonShuffle.setImageResource(R.drawable.suffle_off)
                }
                musicPlayService!!.updateWidget()
            }
        }

        buttonRepeat.setOnClickListener {
            if (musicPlayService != null) {
                if (musicPlayService!!.repeat == 0) {
                    musicPlayService!!.repeat = 1
                    buttonRepeat.setImageResource(R.drawable.repeat_one)
                } else if (musicPlayService!!.repeat == 1) {
                    musicPlayService!!.repeat = 2
                    buttonRepeat.setImageResource(R.drawable.repeat_all)
                } else {
                    musicPlayService!!.repeat = 0
                    buttonRepeat.setImageResource(R.drawable.repeat_off)
                }
                if (musicPlayService!!.repeat != 2) {
                    musicPlayService!!.shuffle = 0
                    buttonShuffle.setImageResource(R.drawable.suffle_off)
                }
                musicPlayService!!.updateWidget()
            }
        }

        radioButtonLeft.setOnClickListener {
            radioButtonRight.isChecked = false
            setOffsetSettings()
        }

        radioButtonRight.setOnClickListener {
            radioButtonLeft.isChecked = false
            setOffsetSettings()
        }

        checkboxCircadian.setOnClickListener {
            setOffsetSettings()
        }

        spinnerWakeupTime.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {

                if (checkboxCircadian.isChecked) {
                    Log.d("output1", "item selected")
                    setOffsetSettings()
                }

            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerMusic.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0 && spinnerOpened && musicPlayService != null && playFileList != null && playFileList!!.count() != 0) {
                    setOffsetSettings()
                    musicPlayService!!.playSelectedMusic(position - 1)
                    spinnerOpened = false
                }
            }
        }
    }

    override fun setOffsetSettings() {
        val channelNo = if (radioButtonLeft.isChecked) 1 else 0
        if (musicPlayService != null) {
            Log.d("output1", "offset settings")
            musicPlayService!!.setOffset(spinnerWakeupTime.selectedItemPosition + 6, channelNo, checkboxCircadian.isChecked)
        }
    }

    override fun onStart() {
        super.onStart()
        // Bind to the service
        //Start service
        val serviceIntent = Intent(this, MusicPlayService::class.java)
        bindService(serviceIntent, musicServiceConnection, Context.BIND_AUTO_CREATE)
        if (Build.VERSION.SDK_INT > 26) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    override fun onStop() {
        super.onStop()
        // Unbind from the service
        if (isBound) {
            unbindService(musicServiceConnection)
            isBound = false
        }
    }

    private fun checkPermission(): Boolean {
        val currentAPIVersion = Build.VERSION.SDK_INT
        if (currentAPIVersion >= Build.VERSION_CODES.M) {
            val permissionsNotGranted = ArrayList<String>()
            for (permission in neededPermissions) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        permission
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionsNotGranted.add(permission)
                }
            }
            if (permissionsNotGranted.size > 0) {
                var shouldShowAlert = false
                for (permission in permissionsNotGranted) {
                    shouldShowAlert =
                        ActivityCompat.shouldShowRequestPermissionRationale(this, permission)
                }

                val arr = arrayOfNulls<String>(permissionsNotGranted.size)
                val permissions = permissionsNotGranted.toArray(arr)
                if (shouldShowAlert) {
                    showPermissionAlert(permissions)
                } else {
                    requestPermissions(permissions)
                }
                return false
            }
        }
        return true
    }

    private fun showPermissionAlert(permissions: Array<String?>) {
        val alertBuilder = AlertDialog.Builder(this)
        alertBuilder.setCancelable(true)
        alertBuilder.setTitle("Permission Required")
        alertBuilder.setMessage("The app needs to read files from your storage.")
        alertBuilder.setPositiveButton(android.R.string.yes) { _, _ ->
            requestPermissions(
                permissions
            )
        }
        val alert = alertBuilder.create()
        alert.show()
    }

    private fun requestPermissions(permissions: Array<String?>) {
        ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CODE -> {
                for (result in grantResults) {
                    if (result == PackageManager.PERMISSION_DENIED) {
                        // Not all permissions granted. Show some message and return.
                        return
                    }
                }
                // All permissions are granted. Do the work accordingly.

            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            1001 -> if (resultCode === Activity.RESULT_OK) {
                if (null != data) {
                    if (null != data.clipData) {
                        for (i in 0 until data.clipData!!.itemCount) {
                            val uri = data.clipData!!.getItemAt(i).uri
                            if (!playList!!.contains(uri) && checkFileFormat(this, uri)) {
                                playList!!.add(uri)
                            }
                        }
                    } else {
                        val uri = data.data!!
                        if (!playList!!.contains(uri) && checkFileFormat(this, uri)) {
                            playList!!.add(uri)
                        }
                    }
                    updatePlayList()
                }
            }
        }
    }

    private fun checkFileFormat(context: Context, uri: Uri) : Boolean {
        val path = Utility.getPath(this, uri).toLowerCase()
        return path.endsWith("mp3") || path.endsWith("wav") || path.endsWith("flac")
    }

    private fun updatePlayList() {
        buttonAddMusic.isEnabled = false
        buttonClearList.isEnabled = false
        progressBar.visibility = View.VISIBLE
        async {
            //create fileInputStream from uri and make a file from it into app's local dir
            if (this@MainActivity.playFileList != null && musicPlayService != null && this@MainActivity.playList != null) {
                await {
                    for (uri in playList!!) {
                        val `in`: InputStream? = contentResolver.openInputStream(uri)
                        val file = File(
                            externalMediaDirs.first(),
                            File(Utility.getPath(baseContext, uri)).name
                        )
                        if (!playFileList!!.contains(file.absolutePath)) {
                            val out: OutputStream = FileOutputStream(file)
                            val buf = ByteArray(1024)
                            var len: Int = 0
                            while (`in`?.read(buf).also({ len = it!! })!! > 0) {
                                out.write(buf, 0, len)
                            }
                            out.close()
                            `in`?.close()
                            playFileList!!.add(file.absolutePath)
                        }
                    }
                }
                //update playlist
                musicPlayService!!.updatePlayList(playFileList!!)
                if (musicPlayService!!.isPlaying)
                    buttonPlay.setImageResource(R.drawable.pause)
                else
                    buttonPlay.setImageResource(R.drawable.play)
                //update spinnerMusicList
                val spinnerArray: MutableList<String> = ArrayList()
                spinnerArray.add("Select a music")
                for (i in playFileList!!.indices) {
                    var title = ""
                    var currentFile = playFileList!![i]
                    try {
                        val metaRetriever = MediaMetadataRetriever()
                        metaRetriever.setDataSource(currentFile)
                        title = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    } catch (e: java.lang.Exception) {
                        title = File(currentFile).name
                    }
                    if (title == "") title = "Unknown Title"
                    spinnerArray.add(title)
                }
                val adapter = ArrayAdapter(
                    this@MainActivity, R.layout.support_simple_spinner_dropdown_item, spinnerArray
                )
                adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item)
                spinnerMusic.adapter = adapter
                spinnerMusic.setSelection(-1)
            }
            progressBar.visibility = View.GONE
            buttonAddMusic.isEnabled = true
            buttonClearList.isEnabled = true
        }
    }

    override fun updatePlayStatus(playList: ArrayList<String>, currentIndex: Int, isPlaying: Boolean) {
        this.playFileList = playList
        updateMusicInfo(currentIndex)
        if (isPlaying) {
            buttonPlay.setImageResource(R.drawable.pause)
        } else {
            buttonPlay.setImageResource(R.drawable.play)
        }
    }

    override fun updateOffsetStatus(channelNo: Int, offset: Int) {
        if (channelNo == 0) {
            textViewLeftOffset.text = "$offset"
            textViewRightOffset.text = "0"
        } else {
            textViewRightOffset.text = "$offset"
            textViewLeftOffset.text = "0"
        }
    }

    private fun updateMusicInfo(currentIndex: Int) {
        if (playFileList == null) return
        val currentFile = playFileList!![currentIndex]

        var artist = ""
        var title = ""

        try {
            val metaRetriever = MediaMetadataRetriever()
            metaRetriever.setDataSource(currentFile)
            artist = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            title = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        } catch (e: java.lang.Exception) {
            artist = "Unknown"
            title = File(currentFile).name
        }

        if (artist == "") artist = "Unknown Artist"
        if (title == "") title = "Unknown Title"

        textViewArtist.text = artist
        textViewTitle.text = title
    }
}
