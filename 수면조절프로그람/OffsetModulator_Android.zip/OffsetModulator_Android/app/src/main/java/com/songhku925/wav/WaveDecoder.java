package com.songhku925.wav;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class WaveDecoder {

    private static final String RIFF_HEADER = "RIFF";
    private static final String WAVE_HEADER = "WAVE";
    private static final String FMT_HEADER = "fmt ";
    private static final String DATA_HEADER = "data";

    private static final int HEADER_SIZE = 44;

    private static final String CHARSET = "ASCII";
    public InputStream stream;

    /* ... */

    public WaveInfo readHeader(InputStream wavStream)
            throws IOException {

        stream = wavStream;

        ByteBuffer buffer = ByteBuffer.allocate(HEADER_SIZE);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        wavStream.read(buffer.array(), buffer.arrayOffset(), buffer.capacity());

        buffer.rewind();
        buffer.position(buffer.position() + 20);
        int format = buffer.getShort();
        int channels = buffer.getShort();
        if (channels != 2) {
            throw new IOException();
        }
        int rate = buffer.getInt();
        buffer.position(buffer.position() + 6);
        int bits = buffer.getShort();
        if (bits != 16){
            throw new IOException();
        }
        int dataSize = 0;
        while (buffer.getInt() != 0x61746164) { // "data" marker
            int size = buffer.getInt();
            wavStream.skip(size);

            buffer.rewind();
            wavStream.read(buffer.array(), buffer.arrayOffset(), 8);
            buffer.rewind();
        }
        dataSize = buffer.getInt();

        return new WaveInfo(format, channels, rate, bits, dataSize);
    }

    public byte[] readWavPcm(WaveInfo info) throws IOException {
        byte[] data = new byte[info.dataSize];
        stream.read(data, 0, data.length);
        return data;
    }

    public class WaveInfo {
        public int format;
        public int channels;
        public int rate;
        public int bits;
        public int dataSize;

        public WaveInfo(int format, int channels, int rate, int bits, int dataSize) {
            this.format = format;
            this.channels = channels;
            this.rate = rate;
            this.bits = bits;
            this.dataSize = dataSize;
        }
    }
}
