package com.songhku925.offsetmodulator

import android.os.Build
import androidx.annotation.RequiresApi
import java.sql.Time
import java.time.Instant
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.floor

class Offset {
    companion object {
        private val sinConst: ArrayList<Double>
            get() = arrayListOf<Double>(
                0.196393398,
                0.383910728,
                0.556674583,
                0.708045747,
                0.832207109,
                0.924387219,
                0.609815084,
                0.761268268,
                0.894328342,
                0.971464030,
                0.907777744,
                0.810252844,
                0.682524699,
                0.529354545,
                0.356452000,
                0.170262237,
                0.001000000,
                0.001000000,
                0.001000000,
                0.001000000,
                0.001000000,
                0.001000000,
                0.001000000,
                0.001000000
            )

        fun getDeviation(wakeupTime: Int, hq: Boolean): Int
        {
            val now = Date()
            //Shifting sinConst so that  the first real element will be for the wakeupTime
            val refValues = getShiftedSinConst(wakeupTime)
            var deviation = getSinValue(refValues, now)
            deviation = if (hq) {
                floor(deviation * 120 + 1)
            } else {
                floor(deviation * 60 + 1)
            }
            return deviation.toInt()
        }

        fun getSinValue(refValue: ArrayList<Double>, date: Date): Double
        {
            val hour = date.hours
            val fraction = date.minutes / 60.0
            val lowerBound = refValue[hour]
            val upperBound =  if (hour == 23) {
                refValue[0]
            } else {
                refValue[hour + 1]
            }
            return lowerBound + (upperBound - lowerBound) * fraction
        }

        private fun getShiftedSinConst(wakeupTime: Int): ArrayList<Double> {
            val refValues = ArrayList<Double>()
            for (c in sinConst) {
                refValues.add(c)
            }
            for (i in 0 until wakeupTime) {
                refValues.add(0, refValues.last())
                refValues.removeAt(refValues.count() - 1)
            }
            refValues.add(refValues[0])
            return refValues
        }
    }
}