package com.songhku925.offsetmodulator

import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.media.*
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.songhku925.flac.common.StreamInfo
import com.songhku925.flac.decode.FlacDecoder
import com.songhku925.wav.WaveDecoder
import javazoom.jl.decoder.Bitstream
import javazoom.jl.decoder.Decoder
import javazoom.jl.decoder.Header
import javazoom.jl.decoder.SampleBuffer
import java.io.File
import java.io.FileInputStream
import java.util.*

class MusicPlayService : Service() {

    private var mAudioTrack: AudioTrack? = null
    private var streamInfo: StreamInfo? = null
    private var flacDecoder: FlacDecoder? = null
    private var waveDecoder: WaveDecoder? = null
    private var waveInfo: WaveDecoder.WaveInfo? = null
    private var sampleRate = 44_100
    private var bitRate = 0

    var currentPath: String? = null
    private var thread: Thread? = null
    var playList: ArrayList<String>? = null

    private val myBinder = MyLocalBinder()
    val CHANNEL_ID: String = "music_service_channel"

    var currentIndex = 0
    var stopRequested: Boolean = true
    var isStopped: Boolean = true
    var isPlaying = false
    var isPaused = false
    var shuffle = 0 // 0 - no suffle, 1 - shuffle
    var repeat = 0 // 0 - no repeat, 1 - repeat one, 2 - repeat all
    var wakeUpTime = 6
    var circadian = false
    var offset = 0 // offset to apply
    var channelNo = 0 // the channel to apply offset
    var isResuming = false // indicates if play function is from resume call

    private var serviceCallbacks: ServiceCallbacks? = null

    fun setServiceCallbacks(serviceCallbacks: ServiceCallbacks) {
        this.serviceCallbacks = serviceCallbacks
    }

    override fun onBind(intent: Intent?): IBinder? {
        return myBinder
    }

    override fun onCreate() {
        super.onCreate()
        //Update ControlWidget
        val updateIntent = Intent(this, ControlWidget::class.java)
        updateIntent.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
        val ids: IntArray = AppWidgetManager.getInstance(application).getAppWidgetIds(ComponentName(
            application, ControlWidget::class.java))
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(updateIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        stop()
        playList = null
        updateWidget()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent!!.action) {
            "updateFromWidgetToService-shuffle" -> {
                if (shuffle == 0) {
                    shuffle = 1
                    repeat = 2
                } else {
                    shuffle = 0
                }
                updateWidget()
            }
            "updateFromWidgetToService-prev" -> {
                if (playList != null && playList!!.count() != 0) {
                    playPrevMusic()
                }
            }
            "updateFromWidgetToService-play" -> {
                if (serviceCallbacks != null && playList != null && playList!!.count() != 0) {
                    if (!isPlaying) {
                        if (isPaused) {
                            pauseResume()
                        } else {
                            serviceCallbacks!!.setOffsetSettings()
                            play()
                        }
                    } else {
                        pauseResume()
                    }
                }
            }
            "updateFromWidgetToService-next" -> {
                if (playList != null && playList!!.count() != 0) {
                    playNextMusic()
                }
            }
            "updateFromWidgetToService-repeat" -> {
                if (repeat == 0) {
                    repeat = 1
                } else if (repeat == 1) {
                    repeat = 2
                } else {
                    repeat = 0
                }
                if (repeat != 2) {
                    shuffle = 0
                }
                updateWidget()
            }
        }

        val notificationIntent = Intent(this, MainActivity::class.java)
//        notificationIntent!!.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0)
        val title: CharSequence = "Music Play Service"
        val content: CharSequence = "Tap to open the app"
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(100, notification)

        return START_STICKY
    }

    inner class MyLocalBinder : Binder() {
        fun getService(): MusicPlayService {
            return this@MusicPlayService
        }
    }

    fun updatePlayList(playList: ArrayList<String>) {
        this.playList = playList
        if (this.playList!!.count() == 0) {
            currentIndex = 0
            stop()
        }
    }

    fun playNextMusic(): Boolean {
        val success = setNextMusic()
        if (success) {
            play()
        } else {
            stop()
        }
        return success
    }

    fun playPrevMusic(): Boolean {
        val success = setPrevMusic()
        if (success)
            play()
        else
            stop()
        return success
    }

    fun playSelectedMusic(index: Int) {
        currentIndex = index
        play()
    }

    fun pauseResume() {
        if (isPlaying) {
            try {
                mAudioTrack!!.pause()
                isPlaying = false
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        } else {
            try {
                mAudioTrack!!.play()
                isPaused = false
                isPlaying = true
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }

        updatePlayStatus()
    }

    fun stop() {
        //Sending stopping signal to the current running thread
        stopRequested = true
        while (!isStopped) {
            Thread.sleep(50)
        }
        isPlaying = false
        isPaused = false

        Log.d("output", "step 2")

        //Release AudioTrack Resource
        try {
            mAudioTrack!!.pause()
            mAudioTrack!!.flush()
            mAudioTrack!!.stop()
            mAudioTrack!!.release()
        } catch (e: java.lang.Exception) {
            print("AudioTrack init failed: $e")
        }
        updatePlayStatus()
    }

    fun play() {
        Log.d("output", "step 0")

        //if no playlist, do nothing
        if (playList == null || playList!!.count() == 0) {
            Toast.makeText(this, "Nothing to play", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("output", "step 1")

        //Sending stopping signal to the current running thread
        stop()

        Log.d("output","step 3")

        //if everything goes smoothly, setting current track
        if (currentIndex in 0 until playList!!.count()) {
            currentPath = playList!![currentIndex]
        } else {
            Toast.makeText(this, "Error with playlist", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("output", "step 4")

        //set audiotrack parameters
        var typeString = ""
        when {
            currentPath!!.toLowerCase().endsWith("mp3") -> {
                //Possible MP3 file that can be played
                // SampleRate 44100 Hz, Channel 2, BitDepth 16 bit
                try {
                    typeString = "mp3"

//                    try {
//                        val bitStream = Bitstream(FileInputStream(currentPath!!))
//                        val header = bitStream.readFrame()
//                        bitStream.closeFrame()
//                        val rate = header.toString()
//                        // Regex to match "ll" in a string
//                        val pattern1 = Regex(pattern = "\\d+(.\\d+)* kHz")
//                        val ans : MatchResult? = pattern1.find(rate, 0)
//                        if (ans?.groups?.count() == 1){
//                            sampleRate = (ans.value.replace("[^0-9.]".toRegex(), "").toDouble() * 1000).toInt()
//                        } else if (ans?.groups?.count() == 2) {
//                            sampleRate = (ans.groups.first()?.value!!.replace("[^0-9.]".toRegex(), "").toDouble() * 1000).toInt()
//                        }
//                    } catch (e: java.lang.Exception) {
//                        e.printStackTrace()
//                        sampleRate = 44_100
//                    }
                    val mex = MediaExtractor()
                    try {
                        mex.setDataSource(currentPath!!) // the adresss location of the sound on sdcard.
                        val mf: MediaFormat = mex.getTrackFormat(0)
                        bitRate = mf.getInteger(MediaFormat.KEY_BIT_RATE)
                        sampleRate = mf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    } catch (e: java.lang.Exception) {
                        // TODO Auto-generated catch block
                        e.printStackTrace()
                        sampleRate = 44_100
                    }



                    val minBufferSize = AudioTrack.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )

                    mAudioTrack = AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBufferSize,
                        AudioTrack.MODE_STREAM
                    )
                } catch (e: java.lang.Exception) {
                    typeString = ""
                    print("mp3 setup failed: $e")
                }
            }
            currentPath!!.toLowerCase().endsWith("wav") -> {
                //Possible wav files that can be played
                //SampleRate not matter, Channel 2, BitDepth 16 bit
                try {
                    waveDecoder = WaveDecoder()
                    waveInfo = waveDecoder!!.readHeader(FileInputStream(currentPath!!))
                    typeString = "wav"
                    sampleRate = waveInfo!!.rate
                    val minBufferSize = AudioTrack.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )

                    mAudioTrack = AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBufferSize,
                        AudioTrack.MODE_STREAM
                    )
                } catch (e: java.lang.Exception) {
                    typeString = ""
                    print("wav setup failed: $e")
                }
            }
            currentPath!!.toLowerCase().endsWith("flac") -> {
                //Possible flac files that can be played
                //SampleRate not matter, Channel 2, BitDepth 24 bit
                try {
                    typeString = "flac"
                    //process flac files
                    val file = File(currentPath)
                    flacDecoder = FlacDecoder(file)
                    // Handle metadata header blocks
                    while (flacDecoder!!.readAndHandleMetadataBlock() != null);
                    streamInfo = flacDecoder!!.streamInfo

                    sampleRate = streamInfo!!.sampleRate
                    var channelType: Int = 0
                    if (streamInfo!!.numChannels == 1) {
                        typeString = ""
                    } else {
                        channelType = AudioFormat.CHANNEL_OUT_STEREO
                    }

                    val minBufferSize = AudioTrack.getMinBufferSize(
                        sampleRate,
                        channelType,
                        AudioFormat.ENCODING_PCM_FLOAT
                    )

                    mAudioTrack = AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        sampleRate,
                        channelType,
                        AudioFormat.ENCODING_PCM_FLOAT,
                        minBufferSize,
                        AudioTrack.MODE_STREAM
                    )

                } catch (e: java.lang.Exception) {
                    typeString = ""
                    print("flac setup failed: $e")
                }
            }
        }

        Log.d("output", "step 5")

        if (typeString != "") {

            //set playing variable to true
            stopRequested = false
            isStopped = false
            isPlaying = true

            updatePlayStatus()
            //generate offset
            generateOffset()
            //Create play thread

            //setting listener to AudioTrack
            mAudioTrack!!.positionNotificationPeriod = 20
            mAudioTrack!!.setPlaybackPositionUpdateListener(object :
                AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack?) {
                }

                override fun onPeriodicNotification(track: AudioTrack?) {
                    if (isStopped && !stopRequested) {
                        Log.d("output", "step 8")
                        playNextMusic()
                    }
                }
            })

            thread = Thread(Runnable {
                Log.d("output", "step 6")
                //Now, let's play music!!!
                try {
                    //Playing each format
                    when (typeString) {
                        "mp3" -> {
                            //prepare mp3 decode variables
                            val bitStream = Bitstream(FileInputStream(currentPath!!))
                            val readThreshold = 2147483647
                            var framesRead = 0
                            var header: Header? = null
                            val mDecoder = Decoder()

                            //get the offsetFrameCount
                            val offsetFrameCount = (offset / 1.0e5 * sampleRate).toInt()
                            //setup buffer variable
                            val bufferQueue: Queue<Short> = LinkedList()

                            var backupArray: ShortArray? = null

                            //process mp3 data
                            while (framesRead++ <= readThreshold) {
                                //if thread interrupt signal is detected, break out the while loop
                                if (stopRequested) break

                                if (isPaused) {
                                    Thread.sleep(50)
                                    continue
                                }

                                if (backupArray != null) {
                                    mAudioTrack!!.write(backupArray, 0, backupArray.count(), AudioTrack.WRITE_BLOCKING)
                                }
                                //read buffer into buffer array
                                header = bitStream.readFrame()
                                if (header == null) {
                                    break
                                }

                                val sampleBuffer =
                                    mDecoder.decodeFrame(header, bitStream) as SampleBuffer
                                val buffer = sampleBuffer.buffer

                                //Process buffer before supplying it to AudioTracker
                                //For testing, block left channel
                                for (i in buffer.indices) {
                                    //if thread interrupt signal is detected, break out this for loop
                                    if (stopRequested) {
                                        break
                                    }

                                    if (i % 2 == channelNo) { //channelNo=0 => left, channelNo=1 => right
                                        if (bufferQueue.count() < offsetFrameCount) {
                                            bufferQueue.add(buffer[i])
                                            buffer[i] = 0
                                        } else {
                                            bufferQueue.add(buffer[i])
                                            if (!bufferQueue.isEmpty())
                                                buffer[i] = bufferQueue.remove()
                                        }
                                    }
                                }

                                //final checkpoint of the stopping thread
                                if (stopRequested) {
                                    break
                                }

                                mAudioTrack!!.write(buffer, 0, buffer.count(), AudioTrack.WRITE_BLOCKING)
                                if (!isPlaying) {
                                    backupArray = buffer
                                    mAudioTrack!!.flush()
                                    isPaused = true
                                } else {
                                    backupArray = null
                                }
                                bitStream.closeFrame()
                            }

                        }

                        "wav" -> {
                            //read all data from wav file into data variable
                            val data = waveDecoder!!.readWavPcm(waveInfo)
                            //setup current frame position
                            var position = 0
                            //get the offsetFrameCount, because supported wav format is 16 bit depth,
                            //should be multiplied by 2, because it's ByteArray
                            val offsetFrameCount = (offset / 1e5 * waveInfo!!.rate).toInt() * 2
                            //setting up buffer variables for frame shifting
                            val bufferArray = ByteArray(data.size / 2)
                            var bufferCount = 0
                            var backupArray: ByteArray? = null
                            var j = 0
                            //process wav frames
                            while (true) {
                                //if thread interrupt signal is detected, break out the while loop
                                if (stopRequested) break

                                if (isPaused) {
                                    Thread.sleep(50)
                                    continue
                                }

                                if (backupArray != null) {
                                    mAudioTrack!!.write(backupArray, 0, backupArray.count(), AudioTrack.WRITE_BLOCKING)
                                }

                                //Read buffer
                                val bufferSize = mAudioTrack!!.bufferSizeInFrames * 4
                                val buffer = ByteArray(bufferSize)
                                var readSize = 0
                                for (i in 0 until bufferSize) {
                                    //if thread interrupt signal is detected, break out this for loop while loop
                                    if (stopRequested) break

                                    buffer[i] = data[position]
                                    readSize++
                                    position++
                                    if (position >= waveInfo!!.dataSize) break
                                }

                                //in case they break out the for loop, break this while loop
                                if (stopRequested) break

                                //Process buffer before supplying it to AudioTracker
                                //For testing, block the left channel
                                for (i in 0 until readSize) {
                                    //if thread interrupt signal is detected, break out this for loop while loop
                                    if (stopRequested) break

                                    if (i % 4 == 2 * channelNo || i % 4 == 2 * channelNo + 1) {
                                        bufferArray[j] = buffer[i]
                                        if (bufferCount < offsetFrameCount) {
                                            bufferCount++
                                            buffer[i] = 0
                                        } else {
                                            buffer[i] = bufferArray[j - offsetFrameCount]
                                        }
                                        j++
                                    }
                                }

                                //in case they break out the for loop, break this while loop
                                if (stopRequested) break

                                //Write buffer to AudioTrack
                                mAudioTrack!!.write(buffer, 0, readSize, AudioTrack.WRITE_BLOCKING)
                                if (!isPlaying) {
                                    backupArray = buffer
                                    mAudioTrack!!.flush()
                                    isPaused = true
                                } else {
                                    backupArray = null
                                }
                            }

                        }

                        "flac" -> {
                            //prepare sample variables
                            val samples = Array(streamInfo!!.numChannels) { IntArray(65536) }
                            val sampleFloats = FloatArray(65536 * streamInfo!!.numChannels)
                            //setup offset variables
                            val offsetFrameCount = (offset / 1e5 * streamInfo!!.sampleRate).toInt()
                            val bufferQueue =
                                FloatArray(streamInfo!!.numSamples.toInt())
                            var bufferCount = 0
                            var j = 0
                            //calculate modular to convert 16 or 24 bit integers to float
                            val modular = when (streamInfo!!.sampleDepth) {
                                16 -> {
                                    32768.0f
                                }
                                24 -> {
                                    8388608.0f
                                }
                                else -> {
                                    2147483648.0f
                                }
                            }
                            var backupArray: FloatArray? = null
                            //process flac frames
                            while (true) {
                                //if thread interrupt signal is detected, break out the while loop
                                if (stopRequested) break

                                if (isPaused) {
                                    Thread.sleep(50)
                                    continue
                                }

                                if (backupArray != null) {
                                    mAudioTrack!!.write(backupArray, 0, backupArray.count(), AudioTrack.WRITE_BLOCKING)
                                }

                                //decode next audio block
                                val blockSamples = flacDecoder!!.readAudioBlock(samples, 0)
                                //this one is the main breakpoint of this while loop
                                if (blockSamples == 0) break
                                // Convert samples to channel-interleaved bytes in little endian
                                var sampleBytesLen = 0
                                for (i in 0 until blockSamples) {
                                    for (ch in 0 until streamInfo!!.numChannels) {
                                        //if thread interrupt signal is detected, break out the while loop
                                        if (stopRequested) break

                                        val `val` = samples[ch][i]
                                        //changing integer into float type array
                                        sampleFloats[sampleBytesLen] = `val` / modular
                                        sampleBytesLen++
                                    }
                                }

                                //if this breaks out of the prev for loop, let's break this while loop
                                if (stopRequested) break

                                //offsetting one of the channel, here, Channel channelNo is lagging
                                for (i in 0 until sampleBytesLen) {
                                    //if thread interrupt signal is detected, break out the while loop
                                    if (stopRequested) break

                                    if (i % 2 == channelNo) {
                                        bufferQueue[j] = sampleFloats[i]
                                        if (bufferCount < offsetFrameCount) {
                                            bufferCount++
                                            sampleFloats[i] = 0f
                                        } else {
                                            sampleFloats[i] = bufferQueue[j - offsetFrameCount]
                                        }
                                        j++
                                    }
                                }

                                //if this breaks out of the prev for loop, let's break this while loop
                                if (stopRequested) break

//                              Pass the sampleBytes to AudioTrack
                                mAudioTrack!!.write(
                                    sampleFloats,
                                    0,
                                    sampleBytesLen,
                                    AudioTrack.WRITE_BLOCKING
                                )
                                if (!isPlaying) {
                                    backupArray = sampleFloats
                                    mAudioTrack!!.flush()
                                    isPaused = true
                                } else {
                                    backupArray = null
                                }
                            }
                        }
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "This file cannot be played.", Toast.LENGTH_SHORT).show()
                }

                Log.d("output", "step 7")

                //when music reaches to the end, setup stopped flag to true
                isStopped = true
            })

            //start music play thread
            thread!!.start()
            mAudioTrack!!.play()

        } else {
            Toast.makeText(this, "This file cannot be played.", Toast.LENGTH_SHORT).show()
            isStopped = true
            updatePlayStatus()
        }
    }

    private fun setNextMusic(): Boolean {
        if (playList == null) return false
        when (repeat) {
            1 -> { //repeat one
                return true
                //Do nothing
            }
            2 -> { //repeat all
                currentIndex++
                if (currentIndex >= playList!!.count()) {
                    currentIndex = 0
                }
                if (shuffle == 1) {
                    currentIndex = getRandomTrackNumber()
                }
                return true
            }
            else -> { //no repeat
                currentIndex++
                if (currentIndex >= playList!!.count()) {
                    currentIndex = 0
                    return false
                }
                return true
            }
        }

    }

    private fun setPrevMusic(): Boolean {
        if (playList == null) return false
        when (repeat) {
            1 -> { //repeat one
                //Do nothing
                return true
            }
            2 -> { //repeat all
                currentIndex--
                if (currentIndex < 0) {
                    currentIndex = playList!!.count() - 1
                }
                if (shuffle == 1) {
                    currentIndex = getRandomTrackNumber()
                }
                return true
            }
            else -> { //no repeat
                currentIndex--
                if (currentIndex < 0) {
                    currentIndex = playList!!.count() - 1
                    return false
                }
                return true
            }
        }
    }

    private fun getRandomTrackNumber(): Int {
        if (playList == null) return 0
        val count = playList!!.count()
        return (0 until count).random()
    }

    fun setOffset(wakeupTime: Int, channel: Int, circadian: Boolean) {
        Log.d("wakeuptime", "top: $wakeupTime, $channel, $circadian")
        if (this.wakeUpTime == wakeupTime && this.channelNo == channel && this.circadian == circadian) return
        this.wakeUpTime = wakeupTime
        this.channelNo = channel
        this.circadian = circadian
        //first pause music
        generateOffset()
        if (!stopRequested) play()
        Log.d("wakeuptime", "bottom: $wakeupTime, $channel, $circadian")
    }

    fun generateOffset() {
        //determine current track is high quality
        var hq = false
        try {
            hq = !currentPath!!.toLowerCase().endsWith("mp3")
        } catch (e: Exception) {
            offset = 0
            serviceCallbacks!!.updateOffsetStatus(channelNo, offset)
            return
        }
        offset = if (circadian) {
            Offset.getDeviation(wakeUpTime, hq)
        } else {
            if (hq) {
                (1..120).random()
            } else {
                (1..60).random()
            }
        }
        serviceCallbacks!!.updateOffsetStatus(channelNo, offset)
    }

    fun updatePlayStatus() {
        if (serviceCallbacks != null && playList != null && playList!!.count() != 0) {
            serviceCallbacks!!.updatePlayStatus(playList!!, currentIndex, isPlaying)
        }
        updateWidget()
    }

    fun updateWidget() {
        var artist = ""
        var title = ""
        try {
            val currentFile = playList!![currentIndex]
            try {
                val metaRetriever = MediaMetadataRetriever()
                metaRetriever.setDataSource(currentFile)
                artist = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                title = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            } catch (e: java.lang.Exception) {
                artist = "Unknown"
                title = File(currentFile).name
            }
        } catch (e: java.lang.Exception){}


        if (artist == "") artist = "Unknown Artist"
        if (title == "") title = "Unknown Title"
        val intent = Intent(this, ControlWidget::class.java)
        intent.action = "updateFromServiceToWidget"
        intent.putExtra("artist", artist)
        intent.putExtra("title", title)
        intent.putExtra("isPlaying", isPlaying)
        // 0 - no repeat, 1 - repeat one, 2 - repeat all
        intent.putExtra("repeat", repeat)
        // 0 - no suffle, 1 - shuffle
        intent.putExtra("shuffle", shuffle)
        sendBroadcast(intent)
    }
}