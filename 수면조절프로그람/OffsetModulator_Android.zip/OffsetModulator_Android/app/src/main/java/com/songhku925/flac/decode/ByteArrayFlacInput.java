package com.songhku925.flac.decode;

import java.io.IOException;
import java.util.Objects;


/**
 * A FLAC input stream based on a fixed byte array.
 */
public final class ByteArrayFlacInput extends AbstractFlacLowLevelInput {
	
	/*---- Fields ----*/
	
	// The underlying byte array to read from.
	private byte[] data;
	private int offset;
	
	
	
	/*---- Constructors ----*/
	
	public ByteArrayFlacInput(byte[] b) {
		super();
		data = Objects.requireNonNull(b);
		offset = 0;
	}
	
	
	
	/*---- Methods ----*/
	
	public long getLength() {
		return data.length;
	}
	
	
	public void seekTo(long pos) {
		offset = (int)pos;
		positionChanged(pos);
	}
	
	
	protected int readUnderlying(byte[] buf, int off, int len) {
		if (off < 0 || off > buf.length || len < 0 || len > buf.length - off)
			throw new ArrayIndexOutOfBoundsException();
		int n = Math.min(data.length - offset, len);
		if (n == 0)
			return -1;
		System.arraycopy(data, offset, buf, off, n);
		offset += n;
		return n;
	}
	
	
	// Discards data buffers and invalidates this stream. Because this class and its superclass
	// only use memory and have no native resources, it's okay to simply let a ByteArrayFlacInput
	// be garbage-collected without calling close().
	public void close() throws IOException {
		if (data != null) {
			data = null;
			super.close();
		}
	}
	
}
