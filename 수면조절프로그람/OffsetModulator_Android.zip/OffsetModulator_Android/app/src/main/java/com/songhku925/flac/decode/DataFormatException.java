package com.songhku925.flac.decode;


/**
 * Thrown when data being read violates the FLAC file format.
 */
@SuppressWarnings("serial")
public class DataFormatException extends RuntimeException {
	
	/*---- Constructors ----*/
	
	public DataFormatException() {
		super();
	}
	
	
	public DataFormatException(String msg) {
		super(msg);
	}
	
	
	public DataFormatException(String msg, Throwable cause) {
		super(msg, cause);
	}
	
}
