package com.songhku925.offsetmodulator

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews


/**
 * Implementation of App Widget functionality.
 */
class ControlWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // There may be multiple widgets active, so update all of them
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onEnabled(context: Context) {
        // Enter relevant functionality for when the first widget is created
    }

    override fun onDisabled(context: Context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        if ("updateFromServiceToWidget" == intent!!.action) {
            val artist = intent.getStringExtra("artist")
            val title = intent.getStringExtra("title")
            val isPlaying = intent.getBooleanExtra("isPlaying", false)
            val shuffle = intent.getIntExtra("shuffle", 0)
            val repeat = intent.getIntExtra("repeat", 0)
            val views = RemoteViews(context!!.packageName, R.layout.control_widget)
            views.setTextViewText(R.id.textViewArtist, artist)
            views.setTextViewText(R.id.textViewTitle, title)
            if (isPlaying) {
                views.setImageViewResource(R.id.buttonPlay, R.drawable.pause)
            } else {
                views.setImageViewResource(R.id.buttonPlay, R.drawable.play)
            }
            if (shuffle == 0) {
                views.setImageViewResource(R.id.buttonShuffle, R.drawable.suffle_off)
            } else {
                views.setImageViewResource(R.id.buttonShuffle, R.drawable.suffle_on)
            }
            when (repeat) {
                0 -> {
                    views.setImageViewResource(R.id.buttonRepeat, R.drawable.repeat_off)
                }
                1 -> {
                    views.setImageViewResource(R.id.buttonRepeat, R.drawable.repeat_one)
                }
                else -> {
                    views.setImageViewResource(R.id.buttonRepeat, R.drawable.repeat_all)
                }
            }

            val appWidget = ComponentName(context, ControlWidget::class.java)
            val appWidgetManager = AppWidgetManager.getInstance(context)
            // Instruct the widget manager to update the widget
            // Instruct the widget manager to update the widget
            appWidgetManager.updateAppWidget(appWidget, views)
        }
    }
}

internal fun updateAppWidget(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetId: Int
) {
    val views = RemoteViews(context.packageName, R.layout.control_widget)
    //play button action on widget
    var intent = Intent(context, MusicPlayService::class.java)
    intent.action = "updateFromWidgetToService-play"
    var pendingIntent = PendingIntent.getService(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.buttonPlay, pendingIntent)

    //next button action on widget
    intent = Intent(context, MusicPlayService::class.java)
    intent.action = "updateFromWidgetToService-next"
    pendingIntent = PendingIntent.getService(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.buttonNext, pendingIntent)

    //prev button action on widget
    intent = Intent(context, MusicPlayService::class.java)
    intent.action = "updateFromWidgetToService-prev"
    pendingIntent = PendingIntent.getService(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.buttonPrev, pendingIntent)

    //repeat button action on widget
    intent = Intent(context, MusicPlayService::class.java)
    intent.action = "updateFromWidgetToService-repeat"
    pendingIntent = PendingIntent.getService(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.buttonRepeat, pendingIntent)

    //shuffle button action on widget
    intent = Intent(context, MusicPlayService::class.java)
    intent.action = "updateFromWidgetToService-shuffle"
    pendingIntent = PendingIntent.getService(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.buttonShuffle, pendingIntent)

    //title text action on widget
    intent = Intent(context, MainActivity::class.java)
    pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
    views.setOnClickPendingIntent(R.id.textViewTitle, pendingIntent)

    appWidgetManager.updateAppWidget(appWidgetId, views)
}